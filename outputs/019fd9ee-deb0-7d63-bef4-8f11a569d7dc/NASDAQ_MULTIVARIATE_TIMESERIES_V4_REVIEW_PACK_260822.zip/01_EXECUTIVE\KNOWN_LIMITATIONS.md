# Known Limitations and Honest HOLD Reasons

1. The unchanged mean 21/63 CRPS Gate requires at least 2% improvement; V4 achieved 0.99%.
2. Extreme-move Q4 coverage and at least one required stress-regime coverage cell remain below contract thresholds.
3. Only six captured Fed-rate path snapshots and one jobs-consensus event are available. They are retained in the DB but cannot enter coefficients before the frozen 60-event minimum.
4. CME historical FedWatch distributions require licensed access; no scraping bypass or synthetic history was used.
5. FRED/Nasdaq content with redistribution restrictions uses a private raw locator plus SHA rather than republishing the response body.
6. The full local test suite cannot collect under the current Anaconda environment because the already-declared `python-frontmatter` dependency is absent. Focused V3/V4 tests pass, and the GitHub workflow installs the repository with declared dependencies.
7. This is research-only. It is not an official forecast, probability ledger entry, trading signal or automated order system.

