# NASDAQ Multivariate Time-Series V4 Review Pack

Date: 2026-08-22 (Asia/Seoul)  
Model: `shadow.nasdaq_pit_market_event_distribution_v4`  
Latest run: `tsv4-research-bd2ac04e8f0a985d22628a2a`  
Decision: **SHADOW GATE HOLD**

## What this package proves

- Public/official archives were actually fetched and persisted raw-first.
- 72 immutable receipts connect to 113,615 append-only observations with 100% linkage.
- Every forecast origin uses only information available at that origin.
- V4 numerically uses 11–20 preregistered market/expectation features per origin.
- Captured Fed-rate and jobs-consensus inputs are preserved but receive zero coefficient weight while their histories remain below 60 events.
- V1/V2/V3, Scenario V5.2, official forecast ledgers and customer UI were not modified.
- The unchanged Gate did not pass; customer forecast numbers remain hidden.

## Quantitative result

| Metric | Result | Gate |
|---|---:|---:|
| 21-session CRPS improvement | 0.29% | positive |
| 63-session CRPS improvement | 1.69% | positive |
| Mean 21/63 improvement | 0.99% | at least 2% |
| Source receipt linkage | 100% | 100% |
| PIT leakage | 0 | 0 |
| Final state | HOLD | PASS required for customer numbers |

## Directory map

- `01_EXECUTIVE/`: decision, implementation audit and limitations.
- `02_CONTRACT/`: frozen V4 contract and predecessor boundaries.
- `03_SOURCE_AND_MODEL_CODE/`: complete V4 collector, features, model, CLI diff and workflow.
- `04_TESTS/`: focused tests, verification output and environment note.
- `05_DATA_LINEAGE/`: raw receipts, full observation ledger, raw blobs, Parquet view and manifests.
- `06_MODEL_RUNS/`: both append-only V4 runs, latest pointer and backtest ledger.
- `07_WORKBOOK_AND_RENDERS/`: eight-sheet Excel audit view and all sheet renders.
- `08_GIT_EVIDENCE/`: git status/diff and protected-path no-change evidence.
- `MANIFEST.sha256` / `MANIFEST.json`: file-level package integrity.

## Reproduction

With the repository's declared dependencies installed:

```text
python -m ai_fc timeseries-v4-verify-sources
python -m ai_fc timeseries-v4-backtest --bootstrap-iterations 1000
python -m ai_fc timeseries-v4-verify
pytest src/tests/test_multivariate_timeseries_v4.py src/tests/test_multivariate_timeseries_v3.py -q
```

The complete observation ledger is canonical. The Excel `Observations` sheet is a series-level reconciliation view because converting all 113,615 × 14 cells to workbook objects exceeds the artifact renderer's memory budget.

