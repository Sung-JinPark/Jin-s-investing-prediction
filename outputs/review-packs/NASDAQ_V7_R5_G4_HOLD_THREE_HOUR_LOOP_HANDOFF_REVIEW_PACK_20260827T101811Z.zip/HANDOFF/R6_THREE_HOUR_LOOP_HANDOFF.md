# R5 → 후속 버전 3시간 자율 루프 인계

## 1. 출발점

### 저장소

- worktree: `C:/workspace/ai-investing/worktrees/active/timeseries-v7-r5`
- branch: `codex/timeseries-v7-r5`
- HEAD: `f60c6b08391d254c92252bd11a4204f63ad9311b`
- G4 decision: `HOLD_RESEARCH_GATE`
- customer publication: 금지
- official/champion promotion: 금지

### R5가 증명한 것

R5의 조건부 분산 계열은 E0 대비 CRPS를 개선했다. 특히 h21과 h63은 각각 2%를 넘었고
paired CI 상단도 0 이하였다. 따라서 “예측력이 전혀 없다”가 실패 이유는 아니다. 실패의
직접 원인은 분포 폭과 방향 균형이다. 다만 이 진단은 이미 개봉한 Outer에서 나온 것이므로,
그 수치를 목표함수로 삼아 같은 Outer에 맞추면 안 된다.

### 절대로 다시 하면 안 되는 것

1. R5 Outer score를 다시 생성하거나 Gate를 다시 실행.
2. R5 Outer metric을 보고 scale multiplier·quantile mapping·direction coefficient 선택.
3. Gate 임계, E0 정의, 확률 단위, 기존 role hash 또는 평가 좌표 변경.
4. 실패 성분·실패 iteration 삭제.
5. 새로운 버전을 R5의 연장 실행이라고 부르며 exposure counter를 초기화.
6. 내부 교차검증 PASS를 Research Gate PASS 또는 고객 공개 승인으로 표현.

## 2. 3시간 루프의 정직한 성공 정의

3시간 안에 허용되는 최종 성공 상태는 다음뿐이다.

```text
READY_FOR_PROSPECTIVE_SHADOW
```

필수 의미:

- 새 model/version/contract가 사전등록됨.
- 개발·선택·보정은 R5 Outer를 제외한 자료만 사용함.
- PIT, 역할 분리, E0 내포, deterministic replay가 통과함.
- 후보·하이퍼파라미터·평가법이 새 prospective 결과를 보기 전에 동결됨.
- 앞으로 생성될 미사용 origin에 예측을 append할 수 있음.
- `research_gate_pass=false`, `numbers_visible=false`를 유지함.

3시간 안에 `RESEARCH_GATE_PASS`를 주장할 수 있는 유일한 경우는 R5 개발 과정과 사람에게
노출되지 않은 별도 holdout이 이미 존재하고, 그 봉인·미접근을 파일 해시와 접근 원장으로
독립 증명할 수 있을 때뿐이다. 현재 인계 자료에서는 그런 holdout이 확인되지 않는다.

## 3. 권장 180분 실행 예산

### 0–15분: P0 동결

- R5 HEAD, G4 receipt, Gate JSON, score matrix SHA를 검증한다.
- R5 Outer path를 worker denylist에 넣는다.
- 새 버전 ID, 확률공간, 후보 bundle, random seed, 시간 예산을 append-only 등록한다.
- protected/official/scenario/ledger before manifest를 만든다.

종료 조건: R5 hash 불일치, Outer denylist 우회, dirty protected scope 발견 시 즉시
`BLOCKED_PROTECTED_SCOPE`.

### 15–35분: 데이터·PIT preflight

- XNAS calendar, `available_at <= origin_cutoff_at`, label maturity를 재검증한다.
- train/selection/stacking/calibration만 materialize하고 R5 Outer는 로드하지 않는다.
- cadence별 freshness와 missingness를 기록한다.
- 데이터 부족은 지표 숨김이나 forward fill로 해결하지 않는다.

### 35–60분: 후보 계약 동결

후보는 Outer 결함을 보고 임의 추가하지 말고, 일반적인 distribution calibration과 conditional
location 문제를 다루는 소수 가족으로 사전등록한다. 예시 후보군:

1. `C0`: R5 최종 mixture를 고정 comparator로만 사용.
2. `C1`: cross-fitted monotone quantile calibration. fit fold 밖 quantile만 변환.
3. `C2`: sequential conformal interval calibration. 과거 성숙 오차만 사용.
4. `C3`: shrinkage location expert. 계수 상한과 E0 퇴화점 0을 사전등록.
5. `C4`: C1/C2와 C3의 비음수 convex stack. anchor floor 유지.

구체 그리드, fold, seed, 다중성 정책을 이 단계에서 고정한다. R5 Outer metric은 그리드 선택
근거로 사용하지 않는다.

### 60–125분: bounded Ralph iteration

각 iteration은 한 task만 수행한다.

```text
diagnose -> patch -> allowlist check -> targeted tests
-> inner rolling-origin evaluation -> decision -> append receipt -> commit
```

라우터가 허용할 자동 수정:

- PIT 정렬 오류
- 수학식·단위·quantile ordering 오류
- cross-fit fold contamination
- deterministic seed/replay 오류
- 런타임·메모리 최적화
- 사전등록 후보 범위 안의 선택

자동 수정 금지:

- Gate/coverage 임계 완화
- 사전등록 후 후보 가족 추가
- R5 Outer를 이용한 early stopping 또는 loss
- 확률 clipping·silent normalization
- 결과 삭제·best-run cherry-pick

반복 상한은 12회, 동일 blocker 3회면 정지한다. 모든 시도와 실패를 남긴다.

### 125–155분: 내부 봉인 평가

- nested rolling-origin, purge 63거래일, embargo 5거래일을 적용한다.
- 모델 선택 fold와 최종 내부 확인 fold를 분리한다.
- CRPS, pinball, coverage/width, miss balance, direction, Brier를 함께 기록한다.
- 내부 확인 결과가 좋더라도 `INTERNAL_QUALIFICATION_PASS`로만 표기한다.

권장 내부 readiness 조건은 기존 Gate를 완화하지 않고 동일 계산을 재사용하되, 이것을 공개
Gate로 오인하지 않는 것이다. Gate 함수 자체를 변경하지 않는다.

### 155–175분: prospective freeze

- 모델·feature·calibrator·seed·dependency lock·source hash를 고정한다.
- 각 거래일 장 마감 후 prospective prediction을 append하는 CLI를 준비한다.
- 예측 생성 시점에는 actual label을 알 수 없어야 한다.
- prediction, resolution, correction 원장을 분리하고 correction은 `supersedes`로만 기록한다.

### 175–180분: 종료 보고

허용 종료 상태:

- `READY_FOR_PROSPECTIVE_SHADOW`
- `HOLD_INTERNAL_QUALIFICATION`
- `BLOCKED_DATA`
- `BLOCKED_PROTECTED_SCOPE`
- `BLOCKED_REPEATED_DEFECT`

`RESEARCH_GATE_PASS`는 prospective Gate가 실제 실행되지 않았다면 허용하지 않는다.

## 4. Controller 계약

권장 CLI:

```powershell
python tools/ralph_timeseries_next.py run `
  --max-hours 3 `
  --max-iterations 12 `
  --outer-policy prospective-only `
  --stop-at READY_FOR_PROSPECTIVE_SHADOW,HOLD_INTERNAL_QUALIFICATION,BLOCKED_DATA
```

필수 controller 상태:

```text
BOOTSTRAP
PREFLIGHT
CONTRACT_FROZEN
ITERATING
INTERNAL_EVALUATION
PROSPECTIVE_FROZEN
READY_FOR_PROSPECTIVE_SHADOW | HOLD_* | BLOCKED_*
```

각 iteration receipt 필수 필드:

- run_id, iteration_id, task_id
- started_at, completed_at, duration, return_code
- code/input/output hashes
- role rows accessed
- outer/prospective exposure counters
- commands and test results
- defect classification
- changed paths and allowlist result
- protected before/after hash
- secret scan result
- next state

## 5. 새 prospective Gate

최초 h63 label은 예측 origin으로부터 63개 완료 XNAS session 뒤에만 성숙한다. 따라서 세 시간
동안에는 첫 h63 prospective score조차 만들 수 없다. 필요한 origin 수, weekly grid, power와
Gate 실행일은 첫 prediction 전에 계약으로 고정해야 한다.

다음 원칙을 권장한다.

- R5 Outer는 새 버전의 training/selection/calibration/Gate 어디에도 사용하지 않는다.
- prospective prediction은 매 origin마다 실제값 공개 전에 append한다.
- score는 horizon 성숙 후 append하고 기존 prediction을 수정하지 않는다.
- 최소 표본과 crisis coverage feasibility를 사전 계산한다.
- 마지막 required horizon과 origin이 성숙한 후 Gate를 정확히 한 번 실행한다.
- 실패하면 결과를 동결하고 다음 버전은 다시 새 prospective window를 요구한다.

## 6. 검토자가 답해야 할 질문

1. R5 Outer 외에 실제로 미접근 상태가 증명되는 holdout이 존재하는가?
2. 없다면 prospective Gate의 최소 origin 수와 예상 완료일은 언제인가?
3. C1–C4 후보는 R5 Outer 결과를 보지 않고도 정당화되는 사전등록 가족인가?
4. calibration fit/evaluation의 역할 분리가 leakage 없이 가능한가?
5. 방향 모델의 신호가 calibration 내부에서 안정적인가, 아니면 weight 0이 맞는가?
6. 3시간 루프의 성공 표기가 공개 Gate와 명확히 분리되는가?
7. 실패 iteration을 포함한 append-only experiment registry가 있는가?

## 7. 현재 증거 식별자

- R5 G4 Gate JSON SHA-256:
  `338d3b5f192d2c49ff9173d5322a243008203a5fcc48a786d541a3710979d5a3`
- Outer receipt SHA-256:
  `c6c607b109a1eaacf3a6c50a5ff8e5bb375521ae3fe7109ffe18b90e8022a957`
- Outer score matrix SHA-256:
  `7c3efc2ca0dc9f44e973ba58734f69db14fddb3c682b9b48c24f92282ed16721`
- R5 branch HEAD:
  `f60c6b08391d254c92252bd11a4204f63ad9311b`

위 식별자가 다르면 이 인계를 그대로 실행하지 말고 provenance 감사부터 다시 한다.

