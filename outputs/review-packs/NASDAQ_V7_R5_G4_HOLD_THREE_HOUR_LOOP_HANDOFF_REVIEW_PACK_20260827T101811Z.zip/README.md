# NASDAQ V7 R5 G4 HOLD — 검토 및 3시간 루프 인계 팩

작성일: 2026-08-27  
대상 브랜치: `codex/timeseries-v7-r5`  
봉인 결과 커밋: `f60c6b08391d254c92252bd11a4204f63ad9311b`

## 핵심 판정

R5는 구현 실패가 아니라 연구 Gate 실패로 종료됐다. Outer는 765개 origin, 4개 horizon,
총 3,060개 score row를 정확히 한 번 사용했다. CRPS skill은 전 horizon에서 양수였지만,
예측구간이 과도하게 넓고 방향 균형 기준이 낮아 `HOLD_RESEARCH_GATE`가 정본이다.

- h1 skill: 1.0948%
- h5 skill: 1.7954%
- h21 skill: 2.0908%
- h63 skill: 2.4018%
- h21/h63 평균 skill: 2.2463%
- p10–p90 coverage: 95.1961%
- p25–p75 coverage: 81.8301%
- balanced direction accuracy: 50.0%
- Gate deficits: `coverage80_fail`, `coverage50_high`, `balanced_direction_low`

Outer exposure receipt에는 `exposure_count=1`, `retry_allowed=false`가 기록돼 있다. 같은 R5
Outer를 다시 채점하거나 이 결과를 보고 R5 파라미터를 조정해 PASS시키는 것은 금지된다.

## 이 팩으로 검토할 것

1. R5 계약·역할 분리·E0 내포·후보 admission이 사전등록대로 실행됐는가.
2. 저장된 Outer score에서 기존 Gate 결과가 독립 재계산되는가.
3. Outer 정확히 1회 원칙과 결과 불변성이 보존됐는가.
4. 3시간 자동 루프의 성공 정의가 `Gate PASS 조작`이 아니라 새 버전의
   `READY_FOR_PROSPECTIVE_SHADOW`로 제한됐는가.
5. 새 prospective holdout 없이는 독립 Research Gate PASS를 주장할 수 없다는 경계가
   설계에 반영됐는가.

## 주요 파일

- `HANDOFF/R6_THREE_HOUR_LOOP_HANDOFF.md`: 후속 설계자용 상세 인계.
- `EVIDENCE/R5_OUTPUTS/R5-G4/gate_decision.json`: Gate 정본.
- `EVIDENCE/R5_OUTPUTS/R5-G4/outer_exposure_receipt.json`: 단일 노출 영수증.
- `EVIDENCE/R5_OUTPUTS/R5-G4/outer_score_matrix.parquet`: 저장 score matrix.
- `AUDIT/stored_gate_recompute.json`: 저장 score 기반 독립 재계산 대사.
- `SPEC/`: R5 불변 계약과 수학 블루프린트.
- `SOURCE/`: R5 코드 및 직접 호출한 R4 Gate 의존 코드.
- `TESTS/`, `TEST_LOGS/`: 재현 테스트와 실행 로그.
- `GIT/R5_COMMITS.bundle`: R5 증분 커밋 bundle.
- `MANIFEST.sha256`: ZIP 내부 파일별 SHA-256.

## 판정 용어

- `task succeeded`: R5 계약에 맞게 단일 Outer 판정과 증거 보존을 완료했다는 뜻.
- `research Gate passed`: 현재 거짓. 숫자 공개·승격 근거가 없다.
- `READY_FOR_PROSPECTIVE_SHADOW`: 새 버전이 내부 검증을 마치고 앞으로 생성되는 미사용
  데이터에 예측을 고정할 준비가 됐다는 뜻.

