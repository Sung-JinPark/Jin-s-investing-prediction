# 다변량 시계열 게이트 캠페인 검토 (2026-08-28, KST 세션)

- 저장소: C:/workspace/ai-investing (원격 Sung-JinPark/Jin-s-investing-prediction)
- **정본은 저장소다. 이 ZIP은 검토용 파생물이며 저장소에 역주입하지 않는다.**
- 작업 브랜치: `claude/timeseries-v8-b5` @ `b33b2dd7` (PR #77 오픈 중), main @ PR #76까지 머지

## A. 운영 트랙 — FRED 자동업데이트 (완결, 전부 main 머지)

| PR | 내용 | 상태 |
|---|---|---|
| #73 | 일일 DFM prepare(주중 verify 실패 해소) · PR checkout SHA 고정 · V1 replay 해시 `vintage_end` 마스킹 · 월간 backtest path-count 20000 정렬 | 머지 + CI green |
| #75 | V2 체크포인트 push 전 `git pull --rebase` (동시 푸시 경합 수정) | 머지 + main 푸시 런 완전 green |
| #76 | `ops-failure-alert.yml`(실패 시 이슈 자동 생성) · `tools/ops_status.py`(세션 상태 점검) · KNOWN_LIMITS #33 (DTWEXBGS 주간 발행 SLA) | 머지 |
| — | `timeseries-refresh` full_backtest dispatch 1회로 V1 해시 재기록 | 성공 |

결론: 수집→체크포인트 커밋→prepare→verify→모델 산출물 커밋 전 단계가 main에서 green.
GitHub cron은 수 시간 지연이 정상 패턴(어제 01:35 예정→11:58 실행)이며 고장이 아니다.

## B. 연구 트랙 — multivariate_timeseries_v8 (PR #74 머지, #77 오픈)

### 구조 (모두 사전등록 계약 `data/contracts/multivariate_timeseries_v8.yaml` 기반)
- V2 봉인평가는 1회 소진·FAIL 확정(`tsv2-backtest-f995c40e…`), model_version 2 재조정 금지 →
  집안 관례대로 새 격리 네임스페이스 `src/ai_fc/timeseries_v8/` + draft 계약 (model_version 8).
- 개발은 2019-blind(2019-04-30 날짜 절단 구조 강제), design window 2007–2014(417 주간원점),
  holdout 2015–2018(최대 3 finalist, finalist당 1회 채점), 실험예산 24회, append-only 실험 원장.
- 중립 설정 = V2 비트 동일(E0 identity, 테스트로 강제). hermetic 테스트 31개.
- 봉인 2019+ 평가는 코드 경로 자체가 없음 — 계약 동결 + **사용자 명시 사인오프 후에만** 추가.

### 실험 결과 (design, h21/h63 CRPS 개선 vs 최우수 baseline)

| 실험 | 구성 | h21 | h63 | 장기평균 | cov80(21/63) | GFC | 판정 |
|---|---|---:|---:|---:|---|---:|---|
| E0 | V2 재현 | −2.64% | −14.37% | −8.51% | .81/.79 | .628 | 기준선 |
| E1/E1b | B1 vol 평균회귀 | — | — | — | — | — | **기각** (대칭 회귀는 양방향 역효과) |
| E2b | B2 위치 앵커 | +0.18% | −7.15% | −3.49% | .83/.81 | .744 | 부분 개선 |
| E4 | B2max+blend | +1.89% | −0.44% | +0.73% | .90/.90 | .769 | — |
| E5 | E4+B4 s=.25 | +2.81% | +0.15% | +1.48% | .84/.85 | .667 | **B1–B4 가족 stop-loss 발동** (< +2%) |
| E6 | **FHS 순수** | +2.38% | +2.82% | +2.60% | .80/.82 | .821 | 돌파 (2009 결함 우위 반전) |
| E7 | FHS+tilt .25 | +2.66% | +2.48% | +2.57% | .82/.82 | .808 | 상쇄 — 기각 |
| E8 | FHS+blend .75 | +3.04% | +3.38% | **+3.21%** | .85/.87 | .821 | CRPS 최고, coverage 밴드 밖 |
| E9 | E8+B4 s=.25 | +2.78% | +1.87% | +2.33% | .80/.81 | .744 | 과절단 — 기각 |
| **E10** | **E8+B4 s=.5** | **+3.02%** | **+2.71%** | **+2.86%** | **.82/.84 전부 밴드 안** | **.782** | **게이트-정합 챔피언** |
| E11 | E10+기간구조 vol | +2.94% | +1.83% | +2.38% | .86/.89 | .718 | 기각 |

핵심 인과 증거: V2의 h63 실패는 반복 VARX의 **장기 위치 동학**(2009 중앙값−실현 −17.1%p,
전체 초과손실의 77%)이 원인이고, FHS(외삽 제거)가 이를 실제로 반전시켰다.

### 결정 이력 (전부 사용자 승인)
1. v8 판정 방식 = 일회성 2019+ 평가 + 준청정 caveat (포워드 shadow로 청정 검증 누적)
2. V7 R6 D1/D2/D3 = 보류 (Codex 트랙 WAIT_USER_DECISIONS 유지)
3. B1–B4 stop-loss 후 B5 활성화 승인
4. R8-D1: dev-gate proxy 증거기반 개정 승인 — `design ≥ +2.5% AND paired se ≤ 0.001 AND
   full-투영 CI90 상단 ≤ −0.0004 AND coverage 게이트 밴드` (원값·근거는 계약 revision_history)

### 현재 대기 상태 (팩 생성 시점)
- **E10 홀드아웃 채점(2015–2018, 20000 paths, 1회 소모) 실행 중** — 완료 시
  `data/timeseries_v8/ledgers/holdout_scorings.jsonl`에 행 추가.
  통과 기준: holdout 장기평균 ≥ +2% AND holdout CI90 상단 ≤ 0.
- 통과 시: 계약 동결(frozen_hash 확정) → PR #77 머지 → 봉인평가는 별도 사인오프.
- 실패 시: E10은 finalist 1/3 소모로 기록되고, 잔여 예산(12회)·finalist(2명)로 재도전 또는 중단.

## C. 증거 파일 (이 ZIP의 EVIDENCE/)
- `multivariate_timeseries_v8.yaml` — draft 계약 (proxy revision 1 포함)
- `R8_STOPLOSS_EVIDENCE_20260828.md` — B1–B4 stop-loss 증거
- `R8_FHS_PHASE_REPORT_20260828.md` — FHS frontier 보고
- `development_experiments.jsonl` — E0~E11 append-only 원장 (행별 content_hash)
- `ralph_state_*.json` — 루프 하네스 상태 2개 (stop_loss_triggered / B5 단계)
