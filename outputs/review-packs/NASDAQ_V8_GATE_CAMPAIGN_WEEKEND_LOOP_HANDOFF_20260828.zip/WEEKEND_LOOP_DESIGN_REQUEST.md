# 주말 세션 요청서 — git bash 상시 루프 설계도 작성

> 이 문서를 주말 Claude Code 세션에 그대로 전달한다. 목적은 **Claude 세션이 꺼져 있어도
> git bash에서 계속 돌아가는 루프의 설계도(및 구현)를 작성**하게 하는 것이다.
> **루프의 최종 목적 = 다변량 시계열 예측 게이트(publication gate) 성공.**
> 먼저 동봉된 `README_REVIEW_20260828.md`를 읽고, 저장소의 최신 상태
> (`git fetch` 후 main·PR #77·`data/timeseries_v8/ledgers/`)를 반드시 재확인한 뒤 설계할 것.

## 1. 출발 상태 (2026-08-28 목요일 세션 종료 시점)

- 게이트-정합 챔피언 **E10** (FHS + blend .75 + B4 s=.5): design 장기평균 +2.86%,
  coverage 전부 게이트 밴드 안, GFC 0.782, full-투영 CI 상단 −0.0004.
- 개정 proxy(사용자 승인 R8-D1)의 design 기준 전부 충족.
- **E10 홀드아웃 채점이 실행 중이었음** — 주말 시점에는
  `data/timeseries_v8/ledgers/holdout_scorings.jsonl` 존재 여부로 결과를 먼저 확인:
  - **통과**(holdout 장기평균 ≥ +2% AND CI 상단 ≤ 0): 남은 것은 계약 동결 준비 + 봉인
    사인오프 — 이 경우 루프의 역할은 §3-B(shadow·회귀 감시)로 좁아진다.
  - **미완/실패**: §3-A(탐색 루프)가 주 역할이 된다. finalist 예산 2/3 남음, 실험예산 12/24 남음.
  - 프로세스가 죽어 미완이면 같은 명령 재실행으로 재개 가능 (결정론·멱등: 동일 config+코드+
    데이터 → 동일 experiment_id, 원장 중복 없음).

## 2. 루프가 절대 넘지 못하는 선 (설계에 하드코딩할 것)

1. **봉인 2019+ 평가는 어떤 자동화로도 실행 금지** — 코드 경로 자체가 없고, 추가하는 것도
   사용자 사인오프 뒤 Claude 세션에서만. 루프가 `sealed` 문자열이 든 verb를 만들면 안 됨.
2. 홀드아웃 채점은 finalist당 1회·최대 3 finalist — **루프가 자동으로 소모하지 않는다**
   (사용자 또는 Claude 세션의 명시 결정으로만).
3. 그리드 밖 파라미터 탐색 금지 — `build_config_from_grids`가 코드로 거부하지만, 루프도
   그리드 내 조합만 큐에 넣는다. 실험예산 24회(원장 행 수) 초과 금지 — 코드가 거부함.
4. 동결 좌표·V2 원장·`forecasts/`·`calibration/` 불변. 계약 yaml 수정은 루프 권한 밖.
5. git: 루프는 **로컬 브랜치 커밋까지만** (append-only 원장·run JSON). push/PR/머지는
   사용자 또는 Claude 세션. GitHub Actions의 데이터 커밋과 경합하지 않도록 main 직접 커밋 금지.
6. 시크릿 불필요(로컬 결정론 수치모델만) — 루프 환경에서 FRED_API_KEY 등을 로드하지 않는다.

## 3. 설계할 루프의 두 모드

### A. 탐색 모드 (홀드아웃 미통과/미결 시)
- 큐: 잔여 그리드 조합 중 사전 정의된 우선순위 목록 (예: E8/E10 주변 미측정 조합 —
  blend {21:.75,63:.5} 교차, tilt+blend+B4 조합 등 — ±0.2pp 예상이므로 기대치는 낮게 명시).
- 반복: `python -m ai_fc timeseries-v8-dev-backtest --label <L> --config '<JSON>'`
  (design, 2000 paths, 회당 ~13분) → 원장 행 확인 → 하네스 record → 다음.
- 정지: 예산 소진 · 큐 소진 · 신규 조합이 챔피언을 1pp 이상 넘지 못하는 상태 2연속 ·
  ABORT 파일 존재.

### B. 감시·누적 모드 (홀드아웃 통과 후 또는 병행)
- 일일 1회: `tools/ops_status.py` 실행 + `timeseries-v8-verify` + hermetic 테스트
  (`pytest src/tests/test_multivariate_timeseries_v8.py -q`) → 결과를 로그·상태 파일에 append.
- (동결 후 활성화될) 포워드 shadow 누적 잡의 자리표시자 설계 포함.

## 4. git bash 상시 실행 요구사항 (설계도가 반드시 답할 것)

- 구동: `nohup bash tools/weekend_loop.sh >> outputs/timeseries_v8/loop/loop.log 2>&1 &`
  형태로 Claude/터미널 종료와 무관하게 지속. Windows 절전/재부팅 후 재개 절차 명시.
- 상태: `outputs/timeseries_v8/loop/state.json` (현재 모드·큐·마지막 experiment_id·시각) —
  크래시 후 같은 명령으로 재개 시 원장과 대사해 이어달리기.
- 환경: venv 고정 경로 `.venv/Scripts/python.exe`, `PYTHONUTF8=1`, 저장소 루트에서 실행.
  scipy 1.17.1·pyarrow 24.0.0 핀 유지 (최신 휠은 Windows 정책이 DLL 차단 — KNOWN 이슈).
- 로그: 회전(일자별), 실패 시 마지막 N줄을 상태 파일에 복사.
- 안전: 이중 실행 방지(lock 파일 + PID 확인), ABORT 파일로 우아한 중단,
  기존 `tools/ralph_timeseries_v8.py`의 가드(동결해시·보호 manifest·blocker 3회)를 재사용.
- 검증: 설계도에는 [드라이런 절차]와 [10분 스모크 시나리오]를 포함할 것.

## 5. 참고 명령·파일 지도

```
.venv/Scripts/python.exe -m ai_fc timeseries-v8-dev-backtest --label L --config '{...}'   # design 평가
.venv/Scripts/python.exe -m ai_fc timeseries-v8-verify                                     # 원장·계약 검증
.venv/Scripts/python.exe tools/ralph_timeseries_v8.py init|next|record|status|abort        # 하네스
data/contracts/multivariate_timeseries_v8.yaml        # 계약 draft (proxy revision 1 포함)
data/timeseries_v8/ledgers/development_experiments.jsonl   # append-only 실험 원장 (예산=행수≤24)
data/timeseries_v8/ledgers/holdout_scorings.jsonl          # 홀드아웃 원장 (존재=채점 완료)
outputs/timeseries_v8/reports/                             # stop-loss·FHS 단계 보고
src/ai_fc/timeseries_v8/{contracts,model,backtest,pipeline,artifact}.py
```

## 6. 산출물 요구

1. `docs/timeseries_v8/WEEKEND_LOOP_DESIGN.md` — 설계도 (상태기계 다이어그램, 모드 전환 규칙,
   가드, 재개 절차, 스모크 시나리오)
2. `tools/weekend_loop.sh` + 필요한 보조 스크립트 — 구현
3. hermetic 테스트 (기존 `src/tests/test_multivariate_timeseries_v8.py` 스타일)
4. 브랜치·PR로 정리 (main 직접 커밋 금지), **inventory 재생성 포함**
   (`cd src && python -m ai_fc inventory` — 잊으면 verify의 drift check가 main을 붉게 만든다)
