﻿# Package scope and exclusions

Included:
- current source, contracts, tests, derived data snapshots and recent implementation reports;
- current static site snapshot;
- Git history/diffs from b01427c and the latest rebase fix;
- targeted DualDB SQLite exports and a full table/coverage audit;
- research-pack r2 artifacts.

Intentionally excluded:
- dualdb/db/dualdb.sqlite (85,512,192 bytes): replaced by schema, table inventory, coverage audit, monthly market panel and targeted table extracts;
- raw Yahoo/ICE price files with redistribution restrictions;
- secrets, caches, virtual environments and build caches;
- the user-owned untracked reports/jins-investing-prediction-architecture.html.

Start with REVIEW_README.md. Do not infer that an excluded raw series is absent from the local workspace; use receipts and derived evidence to distinguish availability from redistribution.
