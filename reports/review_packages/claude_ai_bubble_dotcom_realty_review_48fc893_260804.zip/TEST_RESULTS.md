﻿# Test and build results

Package target: 48fc893 on main
Generated: 2026-08-04 KST

- python -m pytest -q from src: **283 passed in 70.53s**
- python -m ai_fc dashboard --pages-out PACKAGE/site: **success**
- GitHub pages workflow for 48fc893: **success**
- GitHub verify workflow for 48fc893: **success**
- Browser checks before packaging: 1주·1개월·3개월·6개월 lookup buttons each rendered a 9-path rebased SVG; 3개월 mapped to 2026-11-03 and 187 remaining trading days.

The package adds review documentation and evidence exports only; it does not change the model implementation.
