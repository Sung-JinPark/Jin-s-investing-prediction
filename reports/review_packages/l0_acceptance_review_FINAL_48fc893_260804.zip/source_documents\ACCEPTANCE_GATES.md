# ACCEPTANCE_GATES — 게이트·금지 문구·테스트 목록

모든 게이트는 코드 상수+계약 yaml로 사전 등록하고, 게이트 우회는 corrections 경유 승인 없이는 불가하다.

## 1. 데이터 게이트

| 게이트 | 규칙 | 위반 시 |
|---|---|---|
| Recency | company_panel 지표의 max_period < asof−400d → `tag_stale`, coverage 제외 | 값 사용 금지 (F1 재발 차단) |
| PIT | 모든 학습·백테스트 입력 `available_at ≤ 기준시각`; filing_date>asof 제외(기존 :86-88 유지) | 빌드 실패 |
| Coverage | regime map 렌더 ≥0.6 · hazard 상태 승수 사용 ≥0.8 · 미달 시 blocked/base_rate_only 명시 | 지도·승수 비활성 |
| 사건 수 | survival/HMM/Cox 등 학습형 hazard는 확정 사건 ≥8 전 champion 금지(shadow만) | 승격 차단 |
| 세그먼트 | segment_revenue는 filing-level extraction만; 추론·보간·0 대입 금지, `not_disclosed` 유지 | 행 거부 |
| 단위 | 비USD `unit_unsupported` 격리; 정정 대기 필드 정규화 제외(연구팩 규칙 유지) | 행 격리 |
| 불변 | archive/append 원장 기존 바이트 변경 = 감사 violation → CI 실패 (기존 유지) | CI 실패 |
| 결정성 | 같은 asof 재생성 byte/semantic 동일(seed·bootstrap seed 고정) | 테스트 실패 |

## 2. 모델·표시 게이트

| 게이트 | 규칙 |
|---|---|
| Hazard 표기 | 항상 구간(하한~상한)+누적 창. 단일 % 점추정·연도 단정 출력 금지. 전문가 사전분포는 별도 열·별도 라벨 |
| Challenger 승격 | 평가 원장 ≥60거래일 **그리고** CRPS ≤ GBM×0.95 **그리고** p10–p90 coverage 오차 ≤3pp **그리고** PIT 검정 통과 — 전부 만족 + 승인 원장 기록 |
| KNN/유사도 | forward n<20 → 사례 나열 UI, 분포 통계(중앙값 강조) 금지, run asof 표기 의무 |
| O 진입상태 | cohort 백테스트 결과 공표 후에만 상태 규칙 등록 가능(순서 강제); 상태 UI는 근거 표 링크 필수 |
| β 게이트 | 히스테리시스(연속 2회 미달 시 0 전환) + at_boundary 배지 |
| 지평 커버리지 | 버킷 관측 <60 → 적중률 숨김·"축적 중 n/60"(기존 유지, hazard·challenger에도 동일 적용) |
| 소표본 | 조건부 통계에 표본 수 상시 병기(S2=302 등) |

## 3. 금지 문구 — UI 문자열 테스트 (빌드 산출 HTML 대상)

**존재하면 실패**: "붕괴 예정", "붕괴 시점은", "2027년에 터", "2028년에 터", "매수 추천", "매수가", "목표가", "진입 가격", "이 이벤트 때문에 하락", "필연적", "확실"
**존재해야 통과**: "구간", "모델 조건부", "표본", "사전 등록", "이 둘은 더하거나 비교할 수 없습니다"(S1↔hazard 분리 배너), "날짜 비예측"(표본 굴곡), "진입 시점·가격을 추천하지 않습니다"(O 상태 화면), "base_rate_only"(사건 희소 시), "run asof"(유사도)

## 4. 추가 테스트 목록 (기존 283개 불변 + 신규)

**데이터 (12)**
1. 낡은 태그 mock → `tag_stale` 상태·coverage 제외
2. 태그 체인 폴백 순서 준수 (AMZN capex 최신 분기 채택)
3. 지표 결손 사유 구분(tag_missing vs not_disclosed)
4. recency guard 경계(399d 통과/401d 차단)
5. 비USD 격리
6. segment 추론 금지(dimension 없는 세그먼트 값 거부)
7. commitments 보간 금지(누락 분기 결측 유지)
8. circular edge dedup_group 합산 1회
9. edge confirmed 전환에 승인 필수
10. phase boundary sensitivity 재계산 저장 검증
11. fundamentals tier 필드 필수
12. o_entry_cohort PIT(익월 체결·당시 배당만) 규칙 검증

**모델 (7)**
13. hazard 구간 출력 형식(점추정 부재)
14. 사건 <8에서 학습형 champion 시도 → 예외
15. base_rate_only 상태 플래그
16. challenger 승격 4조건 AND 검증
17. cohort 통계 재계산 일치(고정 픽스처)
18. 에피소드 rule v1/v2 병존·버전 라벨
19. anchor overlay/model 분리 필드 소비 확인

**UI (6)**
20. 금지 문구 부재·필수 문구 존재 스캔
21. S1↔hazard 분리 배너
22. KNN n<20 나열형 렌더
23. O 상태 화면 근거 링크 존재
24. run-asof 배지
25. S2 소표본 병기

**감사·원장 (4)**
26. 신규 원장 5종 ledger_registry 등록 동시성
27. walk_forward_runs append-only
28. 사건 정의 yaml validator(민감도 grid 완전성)
29. 결정 근거 run_id 인용 필드(승격·상태 규칙 등록 시)

## 5. 회귀 고정값 (다음 검토에서 그대로 대조)

- AMZN capex records의 `max_period ≥ 2026-03-31` (수정 후)
- MSFT·GOOGL 4지표 각 8행 또는 사유 상태
- era: overlay_start=1995-01 · model_anchor=1996-01 병기
- coverage_latest ≥0.6 도달 시 그 산식 입력의 세그먼트 행 전부 filing-level accession 보유
- 기존: 61라벨·-10.7/+73.8/+140.9 · S1 표본 16,702 · path_realism 12.7/20.9/100/76 불변(같은 asof 기준)
