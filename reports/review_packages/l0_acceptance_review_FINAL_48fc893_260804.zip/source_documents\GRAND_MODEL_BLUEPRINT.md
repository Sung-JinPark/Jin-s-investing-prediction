# GRAND_MODEL_BLUEPRINT — AI 위험시계 · 닷컴 재구축 · O 진입 · 조정 앙상블

전제: INDEPENDENT_REVIEW의 F1·F2(P0) 수정 후 착수. 모든 신규 산출물은 확률공간 표기·available_at·영수증·ledger_registry 등록을 공통 의무로 한다.

## 1. 데이터 계층 지도

```mermaid
flowchart TB
  subgraph L1[원천]
    SEC[SEC Companyfacts + 10-Q/K filing tables]
    FRED[FRED/ALFRED]
    YH[Yahoo 파생 진단]
    DD[(DualDB: price/derived/valuation/episode)]
    MAN[수동 tier 원장: IPO·casualty·commitments]
  end
  subgraph L2[패널·원장]
    CP[company_panel_quarterly]
    SEG[segment_revenue_filing]
    COM[commitments_maturity]
    SUP[supply_power_panel]
    CFE[circular_finance_edges]
    PH[dotcom_phase_ledger]
    FA[fundamentals_annual 충전]
    OC[o_entry_cohort_monthly]
    OF[o_fundamentals_quarterly]
  end
  subgraph L3[사건·모델]
    EV[사건 정의 4종 + 민감도 grid]
    HZ[분기 hazard: base-rate + survival]
    CH[조정 challenger ensemble - shadow]
    ST[O 진입상태 rules]
  end
  subgraph L4[검증]
    WF[walk-forward / calibration 원장]
    GT[coverage·승격 gate]
  end
  L1-->L2-->L3-->L4
  EV-->|질문 등록|QR[기존 questions/registry C03]
  HZ-->|physical_event|QR
```

핵심 통합 결정: **hazard의 사건들은 기존 질문 등록부(C03)에 physical_event 질문으로 사전 등록**하고, 기존 해소·채점·캘리브레이션 기계(C17·C18)로 그대로 채점한다. 새 채점 체계를 만들지 않는다.

## 2. AI 버블 사건 정의 (복수, 각각 독립 채점)

| 사건 | 기본 정의 (v1) | 민감도 grid (전부 병행 산출) | 확률공간 |
|---|---|---|---|
| `PRICE_BUST` | NDX가 직전 252d 고점 대비 −30% 도달 후 126거래일 내 고점 −15% 이내 회복 실패 | 깊이 {−20,−30,−40} × 회복창 {63,126,252d} = 9칸 | physical_event |
| `CAPITAL_CYCLE_BREAK` | 4사 합산 capex YoY가 2분기 연속 < 0 **그리고** (AI/cloud 세그먼트 매출 YoY − capex YoY) 악화 2분기 지속 | capex 문턱 {0%, −10%} × 지속 {2,3분기} | physical_event |
| `FINANCING_STRESS` | HY OAS ≥ +300bp(6개월 저점 대비) **그리고** 대상 기업 CDS/신용스프레드 상위군 동반 확대 **그리고** circular edge 취소·재협상 ≥1건 공시 | OAS {+200,+300,+400} × {2-of-3, 3-of-3} | physical_event |
| `COMPOSITE_AI_BUST` | 위 3종 중 2개가 동일 4분기 창에서 충족 | {1-of-3, 2-of-3, 3-of-3} | physical_event |

- 각 정의는 `data/contracts/ai_bust_event_definitions.yaml`에 사전 등록(버전·변경은 corrections 경유). 임계값은 위 grid를 **전부 저장**하고 헤드라인은 v1 셀 하나로 고정 — "임계값을 바꾸니 결과가 바뀐다"를 숨기지 않는다.
- 분기 hazard 산출식(초기): `P(event in Q_k | info_t) = 1 − exp(−λ_k)`, λ_k = base-rate prior × 상태 승수. **base-rate prior**: 역사 아날로그 풀(닷컴·1929·일본·니프티50·크립토·바이오텍 — era 테이블 8종 중 결과 확정 6종)에서 "과열 진입 후 n분기 내 PRICE_BUST 상당 사건" 빈도를 구간 추정(사건 6~8건 → **점추정 금지, 구간만**). **상태 승수**: regime map 좌표(coverage ≥0.8 이후)에서 사분면별 사전 등록 배수(예: 좌하 1.5~2.5 구간). 사건 표본이 이 수준인 동안 §3.3의 ML 후보(변화점·HMM·Cox)는 전부 **shadow 전용**이며 champion 승격 금지 — ACCEPTANCE_GATES 참조.
- 출력 표기: 분기별 hazard 구간 + 12/24/36개월 누적 구간 + "전문가 사전분포(운영자 가설 2027H2~2028H2)"를 **별도 열**로 병기해 데이터 기반과 인간 가설을 시각 분리.

## 3. 신규 테이블 스키마 (전 테이블 공통: `available_at, source_url, source_fingerprint, revision_vintage, value_status{reported/derived/estimated/not_disclosed/tag_stale}`)

### 3.1 `company_panel_quarterly` (F1·F2 수정 포함 재정의)
PK `(company, metric, observation_period, available_at)` · 단위 USD(비USD 격리) · 주기 분기
- metric: capex, ocf, fcf(derived), dna, debt_issued, debt_repaid, interest, cash, rpo, useful_life_change(flag)
- **태그 체인**: `data/contracts/sec_tag_chains.yaml` — 회사×metric별 우선순위 태그 목록(예: AMZN capex → [PaymentsToAcquireProductiveAssets, PaymentsToAcquirePropertyPlantAndEquipment]) + recency guard(400d) + 체인 소진 시 `tag_missing`
- YTD 분기화 금지 유지, `reporting_basis` 유지

### 3.2 `segment_revenue_filing`
PK `(company, segment_id, observation_period, accession)` · filing-level 추출
- segment_id는 canonical_segment_map.yaml 경유만; 명시 AI 매출 없으면 `not_disclosed`
- 추출 방법 표기: `extraction{xbrl_dim/html_table/manual}` + 표 원문 스냅샷 해시

### 3.3 `commitments_maturity` (maturity wall)
PK `(company, instrument{debt/lease/purchase_commitment/prepaid_compute}, bucket{Y1..Y5,thereafter}, observation_period)`
- 10-K/Q 주석 표 추출(html_table/manual tier) — 분기 롤업 규칙: 최신 공시 우선, 보간 금지
- 파생: `maturity_wall_4q = Σ Y1 buckets / OCF_ttm` (derived 표기)

### 3.4 `circular_finance_edges`
PK `edge_id` · 필드 `from_entity, to_entity, instrument{equity/debt/prepay/compute_credit/lease/guarantee}, amount_usd, first_disclosed_at, accession, source_quote_hash, dedup_group, status{candidate/confirmed/cancelled}, approved_by`
- **중복계상 차단**: 동일 경제 거래의 다중 공시(양측 10-K + 보도)는 같은 `dedup_group`으로 묶고 금액은 그룹당 1회만 집계. LLM은 후보 분류만, confirmed 전환은 승인 원장 경유(기존 C20 패턴).
- 그래프 산출: 노드=기업, 엣지 합계, 순환 탐지(cycle detection)는 derived로만.

### 3.5 `supply_power_panel` (후순위 P3)
GPU lead time·주문 취소·전력계약: 공식 공시·IR 원문만, 주기 불규칙 event 원장. D0 실패 시 결측 유지.

### 3.6 닷컴 재구축
- `dotcom_phase_ledger`: 7국면 사전 등록(요청서 §4.1 그대로) — PK `(phase_id, boundary_rule_version)` · 경계는 가격 정점이 아니라 **당시 관측 가능 지표 규칙**(예: phase2 진입 = 1997-10 아시아 위기 이벤트+HY 확대)으로 정의, `boundary_sensitivity` = 경계 ±1/3/6개월 이동 시 국면 통계 재계산 저장
- `fundamentals_annual` 충전: tier A = SEC EDGAR 원문(1996+ 대형주 10-K 수치 수동 추출, accession 링크), tier B = 신뢰 가능한 2차(출처 명기) — **상위 20 entity(기존 46 중) × 1996~2003 = 최대 160행** 목표, 나머지는 결측 정직 유지
- `cycle_compare` 충전: phase ledger 완성 후 국면×지표(깊이·기간·폭·밸류에이션·issuance) 행렬 자동 산출
- casualty 확장: 상폐·파산 목록을 1차 출처 tier로 재구축, `months_after_index_peak` 일 단위화
- 앵커 분리: era 테이블에 `overlay_start(1995-01)`·`model_anchor(1996-01)` 두 열 신설, era_analog.py·UI 라벨 동기화(F3)

### 3.7 Realty Income
- `o_fundamentals_quarterly`: AFFO/share, payout, occupancy, same-store rent, acquisition volume·cap rate, debt maturity(3.3 재사용), fixed-rate share, rating — 원천: 회사 supplemental(수동 tier, 페이지 해시), 주기 분기
- `o_entry_cohort_monthly`: **1998-01~2005-12 매월 말 진입 가정** × 보유 {3,6,12,24,36개월} × {가격, 총수익 proxy} × {최대낙폭, 회복일수}. 신호 조건부 cohort: Nasdaq 정점 대비 {−10,−20,−30,−40%} 도달 후 / 첫 Fed cut 후 / HY OAS 정점 후 / 10Y 26주 추세 반전 후. PIT 규칙: 월말 신호→익월 첫 거래일 체결, 당시 available 배당·금리만, 거래비용 파라미터 명시. out-of-sample: 2008·2020·2022 동일 파이프라인 재실행.
- 진입상태 `O_ENTRY_{NONE/WATCH/SCALE_IN/ATTRACTIVE/STRESS_ONLY}`: cohort 결과가 나온 **후에** 규칙을 사전 등록(백테스트 전에 상태 규칙 확정 금지 — 순서 역전이 과적합의 정문이다). 상태는 reference_only, 매수가·수량 표기 영구 금지. AI hazard와의 결합은 요청서 §5.3 중간상태(충격 유형 분기)를 그대로 채택하고, 시장β·HYβ 중복은 cohort 실측(스트레스 구간 동시 기여 분해)으로 판정한 뒤에만 감쇠 도입.

### 3.8 단기조정 challenger
- 후보: circular block bootstrap(블록 10/21d, 닷컴 전조정+2022~26 AI 조정 풀), GARCH(1,1)/EGARCH, regime-switching jump diffusion(3상태), Bayesian ensemble(GBM+bootstrap+RS 가중).
- 평가(60평가일 원장 축적 후): p10–p90 empirical coverage 오차, CRPS, PIT 히스토그램 평탄성, drawdown 깊이/빈도 분포 vs 실측(에피소드 원장 v2), time-to-trough·회복기간, horizon별(1/3/6/12M) 안정성.
- 산출 UI는 기존 그래프 계약 유지: fan=분포, 굵은 선=illustrative sample 영구 분리, 조정 요약은 "향후 1/3/6개월 내 −5/10/15/20% 경험 비중"(path_realism 확장)으로만.

## 4. UI 정보구조·의미 가드레일

1. 위험시계 화면은 **사건 4종 × hazard 구간 막대**(점 날짜 없음) + 전문가 사전분포 병렬 열 + "coverage·게이트 상태" 상단 고정.
2. S1 83%와 hazard는 다른 페이지·다른 색 체계·상호 링크 금지 배너("이 둘은 더하거나 비교할 수 없습니다").
3. KNN·유사도: n<20 표본은 사례 나열 UI 강제(F6), run asof 병기(F5).
4. O 진입상태: 상태 배지 + "근거 cohort 표" 링크 필수, 가격·시점 단정 문구 금지어 테스트.
5. 조정 통계는 rule_version(월간 v1/일간 v2) 라벨 표기.
6. 캘린더 마커·표본 굴곡 비인과 문구(기존) 유지.

## 5. Walk-forward·Calibration 설계

- 공통 원장 `data/validation/walk_forward_runs/` (append-only): run_id, model, train_end, test window, 지표(Brier, log loss, calibration slope/intercept, time-dependent AUC, false-alarm lead time), config hash.
- 분할 규칙: 연 단위 expanding window, 최소 train 3년; DualDB 유사도 모델은 **nested**(외부 루프에서 anchor·k·feature 고정 후 내부 평가) — anchor를 성능 보고 고르는 행위 자체를 차단.
- hazard는 사건 희소로 walk-forward가 성립하지 않는 동안 `base_rate_only` 상태를 명시 출력 — 지표 산출을 흉내 내지 않는다.
- challenger 승격·상태 규칙 확정·감쇠 도입 등 모든 "결정"은 validation 원장의 특정 run_id를 인용해야 한다(결정 근거의 추적 가능성).
