# IMPLEMENTATION_SEQUENCE — L0→L4 실행 순서

정렬 기준(요청서 §8): "AI 붕괴 시점 분포 또는 O 진입상태의 불확실성을 얼마나 줄이는가".
의존성 원칙: 데이터 신뢰(P0) 없이는 어떤 모델 작업도 착수하지 않는다.

## L0 — 즉시 (P0 + 정합, ~3일)

| # | 작업 | 파일 | 산출물/테스트 | 비용 |
|---|---|---|---|---|
| L0-1 | **F1 태그 체인 + recency guard** | `ai_capital_cycle.py:70-105`, 신규 `contracts/sec_tag_chains.yaml` | AMZN capex가 2024~26 분기로 교체되거나 `tag_stale`로 명시; 테스트: 낡은 태그 mock→stale 상태 | 소 |
| L0-2 | **F2 지표 상태 열** | 동일 + coverage 산식 | MSFT·GOOGL D&A/debt가 `tag_missing/not_disclosed`로 구분 기록 | 소 |
| L0-3 | F3 앵커 필드 분리 | era 테이블(신열), `era_analog.py:16`, UI 라벨 | overlay_start=1995-01·model_anchor=1996-01 병기; 문자열 테스트 | 소 |
| L0-4 | F5 model_run cadence 등록 | ledger_registry + UI run-asof 배지 | 감사에서 dualdb 모델 정체가 stalled로 검출 | 소 |
| L0-5 | F7 β 게이트 히스테리시스 | realty_income.py significance_gate | 연속 2회 미달 시에만 0 전환 테스트 | 소 |
| L0-6 | F6·F11 UI 소표본 표기 | dashboard.js | KNN 사례 나열형·S2 n=302 표기 문자열 테스트 | 소 |

기존 283 테스트 유지 + 신규 ~10개. payload 증가 무시 가능.

## L1 — 계약·수집 (2주 묶음)

| # | 작업 | 내용 | 완료 기준 |
|---|---|---|---|
| L1-1 | 세그먼트 filing 추출 v1 | 4사 × 최근 12분기 10-Q/K 세그먼트 표 → `segment_revenue_filing` (accession·표 해시) | coverage_latest ≥ 0.6, 지도 렌더 게이트 해제; 추출 방식별 status 표기 |
| L1-2 | 사건 정의 등록 | `ai_bust_event_definitions.yaml` + C03 질문 4건 등록(민감도 grid는 데이터로) | validator + 질문 등록부 반영 |
| L1-3 | O 펀더멘털 패널 시작 | supplemental 수동 tier 최근 8분기(AFFO·payout·occupancy·만기) | `o_fundamentals_quarterly` ≥ 32행, 원장 등록 |
| L1-4 | 닷컴 fundamentals tier A 착수 | 상위 8 entity × 1996~2003 수동 추출 | fundamentals_annual ≥ 60행, tier·accession 명기 |
| L1-5 | commitments_maturity v1 | 4사 최신 10-K 주석 | maturity wall 파생 1회 산출(derived 표기) |

## L2 — Baseline 모델 (6주 묶음, L1 게이트 통과 후)

| # | 작업 | 완료 기준 |
|---|---|---|
| L2-1 | base-rate hazard v0 | 아날로그 6~8사건 구간 추정 + 분기 hazard 구간 출력, `base_rate_only` 상태 표기; 전문가 사전분포 별도 열 |
| L2-2 | **O rolling-entry cohort 백테스트** | 1998~2005 전 월 × 5보유기간 표 + 신호 조건부 cohort + 2008/2020/2022 OOS; median·hit rate·worst 공개 |
| L2-3 | dotcom_phase_ledger + boundary sensitivity | 7국면 + ±1/3/6개월 재계산 저장; cycle_compare 자동 충전 |
| L2-4 | 조정 에피소드 rule v2(일 단위) | v1 보존 + rule_version 열, AI·닷컴 동일 코드 경로 |
| L2-5 | regime map 첫 렌더 | coverage≥0.6 상태에서 사분면·trail(비어있는 분기는 결측 표시) |

## L3 — Challenger·심화 (12주 묶음)

- L3-1 challenger 3종 shadow 가동(승격 금지, 평가 원장만 축적)
- L3-2 circular_finance_edges 후보→승인 파이프라인 + 그래프 뷰
- L3-3 casualty 1차 출처 재구축·확장, KNN nested walk-forward 리포트
- L3-4 O 진입상태 규칙 사전 등록(cohort 결과 인용 필수) → 상태 UI
- L3-5 coverage 0.8 목표: 나머지 5사(NVDA·TSM·ASML·AVGO·ORCL) 패널 확장

## L4 — UI·통합 (L2 이후 병행)

위험시계 화면(사건×hazard 구간), O 진입상태 화면, 닷컴 phase 오버레이 — 전부 Blueprint §4 가드레일 문자열 테스트와 함께.

## 의존성 그래프

```mermaid
flowchart LR
  L0-->L1-->L2-->L3
  L1_1[L1-1 세그먼트]-->L2_5[regime map]
  L1_3-->L2_2[O cohort]-->L3_4[진입상태]
  L2_3[phase ledger]-->L3_3
  L2_4-->L3_1[challenger]
  L2_1-->L3_5
```

주의: L2-2(O cohort)가 전체에서 **단위 정보가치 최대** — 기존 가격·배당·FRED 데이터만으로 즉시 가능하고, O 질문(진입시점)의 불확실성을 직접 줄이며, tail-β 중복 논쟁(F/Round2)의 실증 판정 근거를 만든다. L1이 지연되면 L2-2를 먼저 착수해도 된다(의존성 없음).
