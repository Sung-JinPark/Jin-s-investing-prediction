# INDEPENDENT_REVIEW — 48fc893 반증 중심 검토

검토자 역할: 독립 퀀트 리서치 리드 · 데이터 감사자
대상: `48fc893` (main) · 비교 기준 `b01427c` · manifest 258개 파일 SHA-256 전수 대조 **불일치 0**
방식: evidence JSON·DualDB 추출물·데이터 파일·소스·site payload 상호 대조, 가능한 곳은 재계산

---

## 1. 결론 (1페이지)

이 시스템의 **정직성 기계는 이제 실제로 작동한다.** ai_regime이 coverage 0.0에서 스스로 blocked를 선언하고 지도를 그리지 않는 것, S1 곡선에 path_realism(중앙 최대낙폭 12.7%, 10% 조정 경험 76%)을 병기한 것, 재기준 계산 수정, 지평별 적중 게이트(60관측 미만 숨김), CORR-suffix 방식의 정정 아카이브, method_changes 원장 — 모두 확인했다. 283개 테스트, 영수증, frozen/v2 원장 전환도 실측과 일치한다.

그러나 요청서의 네 질문에 대한 답은 명확하다:

1. **AI 위험시계 — 아직 불가하며, 현재 수집기는 '조용히 낡은 데이터'를 만든다.** coverage 0.0이 문제의 전부가 아니다. 수집된 96행 자체에 P0 결함이 있다: AMZN capex 8행이 전부 **2015-06~2017-03**이다(다른 지표는 2024~2026). 단일 태그 고정 + "마지막 8개 기간" 슬라이스가, 회사가 태그 사용을 중단한 경우 10년 전 데이터를 최신인 양 반환한다. MSFT·GOOGL은 D&A·부채발행 지표가 아예 없다. 이 상태로 coverage를 올리면 **낡거나 결손된 패널 위에 hazard를 쌓게 된다.**
2. **닷컴 DB — 가격·조정파동·밸류에이션은 상당하나, 자본조달·펀더멘털 축이 비어 있다.** price_daily 285,076행, 조정 에피소드 41행(닷컴 6·AI 5, 동일 월간 규칙), valuation_monthly 1,832행은 실질적이다. 그러나 `fundamentals_annual=0`, `cycle_compare=0`, casualty 25행(월 단위·2차 출처), ipo 14행·margin_debt 14행·capex_buildout 11행은 "자본조달·기업 축으로 비교한다"고 말하기에 부족하다. 앵커 불일치(1995-01 vs 1996-01)는 실재한다(era_analog.py:16 vs ERA.csv dotcom anchor_month=1996-01).
3. **O 진입 — 조건부 판단의 뼈대는 생겼으나 진입모델은 아직 없다.** 스프레드 0.36%p·318개월 중 0.3백분위라는 불리한 baseline을 숨기지 않은 것은 옳다. C1~C4가 신호 원장과 실제 배선되어 2/4가 산출된다. 그러나 rolling-entry cohort 백테스트가 없고 AFFO·부채만기·occupancy 패널이 없어 "언제 들어갔어야 했는가"는 검증되지 않은 질문이다. β 게이트는 156 경계에 정확히 걸려 있다(`gate_proximity: at_boundary`) — 다음 주 표본이 155가 되면 경로가 점프한다.
4. **단기조정 사실성 — 표현 계층은 해결, 생성 계층은 미해결.** path_realism·비인과 명시·재기준 수정으로 "매끈한 예언" 문제는 닫혔다. 남은 것은 GBM의 알려진 한계이며, challenger 승격 게이트(60평가일)는 이미 사이트에 각인되어 있다 — 설계대로 지키면 된다.

**우선순위 판정**: P0은 AI 패널 수집기의 신선도·완전성 결함 하나다. 나머지는 "더 모으기"가 아니라 §8 기준(불확실성 감소량)에 따라 배열했다 — 상세는 IMPLEMENTATION_SEQUENCE.

## 2. P0~P3 발견사항

| ID | 심각도 | 발견 | 증거 (파일·필드·수치) | 사용자 영향 | 수정 원칙 |
|---|---|---|---|---|---|
| F1 | **P0** | AMZN capex 8행이 2015-06-30~2017-03-31 — asof 2026-08-03 기준 **9년 낡음** | `company_capex_quarterly_latest.json` records(AMZN·capex, tag `PaymentsToAcquirePropertyPlantAndEquipment`); CURRENT_STATE_AUDIT.records_by_company_metric; 원인 코드 `src/ai_fc/ai_capital_cycle.py:70-105` — 단일 태그 + `latest_by_period[-8:]`는 태그가 단종되면 옛 기간을 반환, 신선도 검증 없음 | regime 계산 개시 즉시 AMZN capex/OCF 비율이 2015년 값으로 오염 (현재는 blocked라 잠복) | 회사별 태그 체인(예: AMZN 후기 `PaymentsToAcquireProductiveAssets` 계열) + **recency guard**: `max_period < asof−400d`면 값 채택 대신 `status=tag_stale`로 기록하고 coverage에서 제외 |
| F2 | **P0** | MSFT·GOOGL 지표 결손: capex·OCF만 존재, D&A·debt_issued 0행 — 결손 사유 미기록 | CURRENT_STATE_AUDIT.records_by_company_metric (MSFT 2지표, GOOGL 2지표 vs AMZN·META 4지표) | coverage 분모 처리로 지도는 막히지만, 결손이 `tag_missing`인지 `not_disclosed`인지 구분 안 돼 수선 불가 | 지표×회사별 상태 열 신설(`collected/tag_missing/not_disclosed/tag_stale`), 태그 체인 등록은 계약 yaml로 사전 등록 |
| F3 | P1 | 닷컴 앵커 이중 정의: UI/era_analog `1995-01` vs DualDB era `1996-01` | `src/ai_fc/era_analog.py:16` (`"dotcom": ("닷컴 1995", "1995-01", True)`) vs `evidence/dualdb/ERA.csv` (dotcom anchor_month=1996-01, peak 2000-03-10) | 위상(M+n) 서사가 1년 흔들림 — "정점 39개월 전" 류 설명 신뢰 훼손 | 필드 분리: `overlay_start`(표시 시작)와 `model_anchor`(위상 기준) + 모든 M+ 표기에 기준 명시. 앵커 민감도(±6·12개월)는 cycle_compare 채우면서 산출 |
| F4 | P1 | `fundamentals_annual=0`, `cycle_compare=0` — 닷컴 비교의 기업·사이클 축 부재 | DUALDB_COVERAGE_AUDIT.table_inventory | "가격 한 줄 비교" 비판을 아직 못 벗어남 | Blueprint §4 tiered 충전 계획 (상위 20 entity 우선, tier 표기) |
| F5 | P1 | model_run 정체: KNN asof 07-17, DTW 07-20 vs 스냅샷 08-03 — 갱신 cadence 미등록 | MODEL_RUN_SUMMARY.csv; ledger_registry에 dualdb model_run 부재 | 화면 유사도(distance 0.2288)가 2주 전 상태인데 최신처럼 읽힘 | model_run을 원장 등록부에 등록(weekly), UI에 run asof 병기 |
| F6 | P1 | KNN forward 표본 n=5를 분포처럼 보일 위험 | LATEST_MODEL_RUNS.json (k=5, n_dotcom_samples=108, correction median −12.92%) | 소표본 중앙값이 "예상 조정폭"으로 읽힘 | UI 계약: n<20이면 개별 5개 사례 나열형으로만 표시, median 강조 금지, `anchor_sensitivity=not_computed` 라벨 유지 |
| F7 | P1 | O β 게이트 경계 고착: rate·credit 모두 obs=156=최소치, `gate_proximity=at_boundary` | rate_sensitivity_latest.json | 표본 1개 이탈 시 used=0으로 경로 점프 (Round2 P2 미해결 확인) | 2주 히스테리시스(연속 2회 미달 시에만 0 전환) + 상태 배지 |
| F8 | P1 | casualty 25행: peak_date 월 단위, 출처 Wikipedia 단일 | DOTCOM_CASUALTY.csv | 생존편향 보정의 근거로 약함 | 1차 출처(SEC/거래소 상폐 공고) tier 추가, 표본 확장 계획(§4.2) — 25행을 "시작점"으로 명시 유지 |
| F9 | P2 | 조정 에피소드 월 단위 규칙 — 닷컴·AI 동일 규칙(확인됨)이나 일 단위 깊이 소실 | CORRECTION_EPISODES_ALL.csv (AI 5행: −26.5/−10.4/−11.9/−9.0/…) | 5~20% 단기조정 통계의 해상도 한계 | 규칙 버전 v2(일 단위)로 재산출하되 v1 행 보존, `rule_version` 열 |
| F10 | P2 | 비USD 단위 무변환 fallback | ai_capital_cycle.py:74 `units.get("USD") or next(iter(...))` | 외화 보고 진입 시 단위 오염 가능 | USD 외 단위는 `unit_unsupported`로 격리 |
| F11 | P2 | S2 표본 302개(1.5%) 조건부 통계의 소표본 미표기 | CURRENT_STATE_AUDIT.path_realism.S2.sample_count=302 | S2 중앙낙폭 12.5%가 과신될 수 있음 | 묶음별 n 상시 표기(이미 데이터 있음 — UI만) |
| F12 | P3 | margin_debt 14 / ipo 14 / capex_buildout 11행 — 연 단위 스켈레톤 | DUALDB_COVERAGE_AUDIT | phase 경계 재현 근거 부족 | Blueprint §4 확장 대상 |
| F13 | P3 | sentiment_weekly 0행 | 동일 | 폭·심리 축 공백 | AAII 등 무료 원천 D0 후 채움 (후순위) |

## 3. 현재 시스템이 답할 수 있는 질문 / 답하면 안 되는 질문

**답할 수 있다 (증거 기반)**
- "지금 모델 가정 아래 연말 ATH 돌파 경로 비중은?" — 83% (scenario_conditional, 표본 16,702)
- "ATH 돌파 경로들도 조정을 겪는가?" — 중앙 최대낙폭 12.7%, 10%+ 조정 경험 76%
- "지난 5년 급락일에 O는 시장과 어떻게 움직였나?" — tail β 0.471, 금리 +100bp당 −8.37%
- "닷컴 완화 구간에서 O·NDX·IYR·금리·HY가 어떻게 움직였나?" — +50.2%/−38.8%/+24.2%/−176bp/−298bp
- "현재 O 스프레드는 역사 대비 어디인가?" — 0.36%p, 2000년 이후 0.3백분위 (진입 매력 없음의 근거)
- "AI 조정 파동의 실측 분포는?" — 2022 이후 5회, 깊이 −9%~−26.5%

**답하면 안 된다 (현 DB로는 허위 정밀)**
- "AI 버블은 몇 년에 터지나" — hazard 모델·사건 정의·패널 모두 부재. S1 83%는 생존확률이 아님(요청서 §2.2 재확인)
- "O는 언제 사야 하나 / 얼마에 사야 하나" — cohort 백테스트 0건, 펀더멘털 패널 0행
- "9/22에 왜 떨어지나" — seed 42 표본 굴곡, 비인과 (이미 UI 명시)
- "닷컴과 지금의 자본조달 구조 비교" — fundamentals·issuance 축 결손
- "KNN이 −12.9% 조정을 예상" — n=5 참고 사례일 뿐

## 4. DB별 채점 (0~5)

| DB | Completeness | Quality | PIT 안전 | Reproducibility | 근거 요약 |
|---|---|---|---|---|---|
| Nasdaq 경로/분위수 | 4.5 | 4.5 | 4.5 | **5** | seed·영수증·결정성·재기준 수정 확인; GBM 한계는 공시됨 |
| AI 자본사이클 | **0.5** | **1** (F1·F2) | 4 (filed≤asof 필터 확인 :86-88) | 4 | 96행 중 AMZN capex 8행 오염·2사 결손; blocked 게이트는 올바름 |
| 닷컴 DualDB | 2.5 | 3.5 | 2.5 (사후 정점 기반 anchor·casualty, PIT 분리 미구현) | 3 (SQLite 비재배포, 추출물로 검증) | 가격·에피소드·밸류에이션 강, 펀더멘털·사이클 0 |
| Realty Income | 3 | 4 | 4 (available_at=수집시각 명시) | 4.5 | 민감도·조건·이벤트 실측 강; cohort·펀더멘털 부재 |
| 단기조정(표현) | 4 | 4.5 | — | 5 | path_realism 실측 일치; 생성기는 GBM 단일 |
| 신호/유동성/캘린더 | 3.5 | 4 | 4 | 4.5 | S5·S6 원천 미확보 정직 표기; 캘린더 53건 confirmed/estimated 분리 |

## 5. 충돌·중복 의미 목록

1. **tail β vs credit β 중복** (기존 Round2 지적 유지): deleveraging O 경로에서 급락일 조건부 시장 β와 HY 민감도가 부분 동일 정보 — 감쇠는 백테스트 전 임의 적용 금지(요청서 §5.3과 일치). cohort 백테스트가 판정 근거를 만든다.
2. **anchor 이중 정의** (F3): overlay와 model이 다른 값을 같은 이름으로 사용.
3. **조정 에피소드(월 단위) vs path_realism(일 단위)**: 같은 "drawdown" 단어가 두 해상도로 존재 — 화면에 규칙 버전 표기 필요 (F9).
4. **S1 83% vs AI hazard**: 확률공간이 다른 두 수치가 인접 화면에 놓일 예정 — Blueprint UI 가드레일에서 물리적 분리와 상호 링크 금지 규정.
5. **KNN correction median −12.92% vs path_realism 중앙 12.7%**: 우연히 유사한 두 수치가 서로 검증하는 것처럼 보일 위험 — 출처·표본·공간이 전혀 다름을 병기.

## 6. 요청서 §3.4 · §4.3 답변 (요약)

**§3.4-1 coverage 0→60% 최소 작업**: 세그먼트 매출은 companyfacts로 불가능하다는 판단은 옳다. 최소 경로는 ① F1·F2 수정(태그 체인·상태 열) ② 4사 최근 12분기 10-Q/10-K **세그먼트 표 filing-level 추출**(회사당 표 1개, 분기 12개 — 수작업 검증 가능한 규모) ③ `not_disclosed` 정직 처리. 이 세 가지로 coverage 산식상 0.6 도달이 산술적으로 가능(4사×2축 중 세그먼트+capex 충족 시).
**§3.4-2 2027H2~2028H2 가설의 leading indicators**: capex 가이던스 하향(발표문 원문), incremental AI revenue/incremental capex 비율 하락 전환, RPO 성장 둔화, GPU lead time 단축·주문취소, HY OAS·CDS 확대, 전력계약 취소 — 각각 Blueprint 패널 필드로 매핑했다.
**§3.4-3 maturity wall**: 부채·리스·purchase commitment의 만기 분포는 10-K 주석 표 추출로만 가능 — commitments 스키마와 분기 롤업 규칙을 Blueprint §3.3에 정의.
**§3.4-4 circular edge schema**: `edge(from, to, instrument, amount, first_disclosed_at, accession, dedup_group)` + 동일 거래 다중 공시 dedup 규칙 — §3.4.
**§3.4-5 "가격만 붕괴 vs 사이클 동반"**: PRICE_BUST와 CAPITAL_CYCLE_BREAK를 독립 사건으로 두고 결합은 COMPOSITE에서만 — 사건 정의 표 §2.
**§4.3 주요**: 앵커 분리(F3), fundamentals 충전 우선순위(§4.2), casualty 확장(F8), 에피소드 규칙 동일성 — **동일함을 확인**(월 단위, 닷컴 6·AI 5행 같은 스키마), KNN 표현 제한(F6), nested walk-forward — anchor·k·feature를 외부 루프에서 고정하는 설계 §7, 거리함수에 구성·수익성·금리 차이 반영 — 보정 항이 아니라 **조건 변수로 병기**(거리 자체를 조작하지 않음).

*발견 중 코드 라인이 특정되지 않은 항목(F5 cadence 등)은 재현 명령과 함께 `검증 필요`로 두었다. 수정은 GRAND_MODEL_BLUEPRINT·IMPLEMENTATION_SEQUENCE를 따른다.*
