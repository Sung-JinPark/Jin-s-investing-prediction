# Verification evidence

- `pytest -q`: **317 passed in 85.99s** (final rerun)
- `node --check dashboard.js`: passed
- `node --check qr-creator.min.js`: passed
- Pages build: passed; index 392,978 bytes, data 232,536 bytes
- OG image: 1200×630 RGB
- QR decoded with OpenCV to `http://127.0.0.1:8898/#asof`
- Browser checks: Decision Journal, share popover, cross-asset contrast and ledger panel passed
