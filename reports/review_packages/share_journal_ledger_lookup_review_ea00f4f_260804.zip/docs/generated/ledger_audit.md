# Ledger accumulation audit

- Generated: `2026-08-04T01:38:05+00:00`
- Latest completed NYSE day: `2026-08-03`
- Result: accumulating 21 · stalled 1 · inactive 0 · violation 0 · planned 3

| Ledger | Cadence | Files / rows | Latest | Status | Finding |
|---|---:|---:|---:|---:|---|
| `forecast_records` | event | 22 | 2026-08-03 | **accumulating** | — |
| `forecast_evidence` | event | 17 | 2026-08-03 | **accumulating** | — |
| `ml_market_history` | weekly | 1 | 2026-08-03 | **accumulating** | — |
| `calibration_ledger` | event | 1 / 6 | 2026-07-31 | **accumulating** | — |
| `corrections_ledger` | event | 1 / 4 | — | **accumulating** | — |
| `benchmark_ledger` | event | 1 / 6 | — | **accumulating** | — |
| `cost_ledger` | event | 1 / 5 | — | **accumulating** | — |
| `provider_shadow_ledger` | event | 1 / 0 | — | **accumulating** | — |
| `scenario_archive` | trading_daily | 3 | 2026-08-03 | **accumulating** | — |
| `scenario_latest` | trading_daily | 1 | 2026-08-03 | **accumulating** | — |
| `cross_asset_archive` | trading_daily | 3 | 2026-08-03 | **accumulating** | — |
| `cross_asset_latest` | trading_daily | 1 | 2026-08-03 | **accumulating** | — |
| `cross_asset_path_tracking` | trading_daily | 1 / 3 | 2026-07-31 | **stalled** | — |
| `signal_archive` | weekly | 2 | 2026-07-31 | **accumulating** | — |
| `liquidity_archive` | weekly | 1 | 2026-07-31 | **accumulating** | — |
| `rate_event_archive` | monthly | 1 | 2026-08-03 | **accumulating** | — |
| `realty_rate_sensitivity_archive` | monthly | 1 | 2026-08-03 | **accumulating** | — |
| `realty_dividends` | monthly | 1 / 343 | 2026-08-03 | **accumulating** | — |
| `ai_capital_archives` | monthly | 3 | 2026-08-03 | **accumulating** | — |
| `source_monitoring` | trading_daily | 2 | 2026-08-03 | **accumulating** | — |
| `raw_receipts` | event | 0 | — | **planned** | — |
| `quarantine` | event | 0 | — | **planned** | — |
| `bitemporal_facts` | event | 0 | — | **planned** | — |
| `forecast_timestamp_proof` | weekly | 1 | 2026-08-03 | **accumulating** | — |
| `research_pack` | monthly | 1 | — | **accumulating** | — |

## Interpretation

`stalled` is an operational warning, not an immutable-record violation. `planned` means the layer is registered before first ingestion. Existing file hash changes and schema failures are `violation` and fail the check gate.
