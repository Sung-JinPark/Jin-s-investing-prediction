# Verification results

- Full suite: `325 passed in 81.13s`
- Ledger audit: `accumulating=23, frozen=1, stalled=0, inactive=0, violation=0, planned=4`
- Browser: cross-asset M+3 attribution visible
- Browser: `gate 경계(n=156)` visible
- Browser: C1-C4 evidence value and as-of visible
- Browser: `BTC 경로 공유 · 설계상 동일` visible after rates-stay-high selection
- Browser: method-change event and implementation-report link visible
- Security scan: clean
- Research pack r2: 22 tables, 311,208 bytes; 2 pending market-probability unit rows retained without normalization
