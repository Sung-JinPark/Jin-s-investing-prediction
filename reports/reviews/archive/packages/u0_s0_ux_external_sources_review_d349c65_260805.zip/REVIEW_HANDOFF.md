# U0 UX Audit + S0 External Source Contracts — Review Handoff

패키지 작성일: 2026-08-05 KST  
저장소: `Sung-JinPark/Jin-s-investing-prediction`  
브랜치: `main`  
기준 커밋: `cea5b9f47e41305fc73ce79c39269a6b2b946744`  
최종 검토 HEAD: `d349c657cab64595fcb133385062962ebebb7ea3`

커밋:

1. `fec9af6fed5b6d45392d77a73b1c1feede5bff44` — `docs(ux): audit routes and stage three P1 D0 contracts [U0 S0]`
2. `d349c657cab64595fcb133385062962ebebb7ea3` — `chore(inventory): register staged D0 contracts [S0]`

## 1. 검토 목적

첨부된 총집합 설계도의 실행 범위를 엄격하게 `U0 + S0`로 제한해 수행했는지 독립적으로 검토한다.

- U0: UI 코드를 바꾸기 전, 전체 라우트·화면 목적·사용자 유형·클릭 깊이·배지·용어·반응형 문제를 감사한다.
- S0: P1 외부 소스 중 정확히 세 건만 선정해 14일 D0 계약 초안을 만든다.
- 금지 범위: U1/U2 UI 재편, collector 구현, source registry 등록, H1~H6 역사 DB 적층.

## 2. 커밋 변경 파일

| 파일 | 역할 | 핵심 판정 | 관련 원칙·테스트 |
|---|---|---|---|
| `reports/md/UX_AUDIT_260805.md` | U0 화면 감사 기준선 | 스크린샷 전체 세트 미충족으로 `PARTIAL`, U1 게이트 차단 | §1.3 P1~P6, `test_u0_audit_keeps_u1_gate_closed_without_full_screenshot_set` |
| `data/contracts/finra_margin_statistics_d0.yaml` | FINRA 마진부채 후보 계약 | `blocked_legal_terms`, fetch·DB·모델 사용 금지 | D0→계약→registry→collector, `test_finra_and_nfci_are_legal_gated_before_fetch` |
| `data/contracts/fred_nfci_d0.yaml` | NFCI 후보 계약 | `legal_review_required`, 기존 FRED 계약의 라이선스 상태 상속 금지 | 동일 테스트 |
| `data/contracts/cftc_cot_bitcoin_d0.yaml` | CFTC BTC 포지셔닝 후보 계약 | 공식 TFF Futures Only 데이터셋으로 D0 모니터링 시작 | PIT, append-only, `test_cftc_bitcoin_contract_pins_tff_dataset_and_pit_availability` |
| `src/tests/test_u0_s0_scope.py` | 범위·법적 게이트·PIT 계약 테스트 | 5개 신규 테스트 | 정확히 3개, disabled, no collector, no registry |
| `docs/generated/inventory.generated.md` | 결정론적 생성 인벤토리 | source contract 20→23, fingerprint 갱신 | `python -m ai_fc inventory --check` |

## 3. U0 감사 핵심 발견

### 라우트와 구조

- 현재 주요 명령 라우트: `#overview`, `#flow`, `#questions`, `#ask`, `#asof`, `#track`.
- flow 하위 상태: `#flow`, `#lab=history`, `#lab=cross-asset`, `#lab=ai-regime`, `#lab=liquidity`.
- 문맥 상태: `#lookup=...`, `#asof=...`, `#q/{id}`, `#compare/{id,id}`.
- 목표 4개 질문 섹션: `오늘`, `미래 탐색`, `기록과 검증`, `데이터와 신뢰`.

### 실측 문제

1. 다섯 lab 화면의 H1이 모두 같은 문장이라 3초 안에 각 화면 목적을 구분하기 어렵다.
2. `#track`은 배지 인스턴스 41개·배지 유형 7개로 한 화면 최대 3종 원칙을 위반한다.
3. `#flow`는 배지 유형은 2개지만 이벤트 상태 반복으로 인스턴스가 53개다.
4. 질문 비교는 홈에서 최대 4클릭이 필요해 3클릭 원칙을 위반한다.
5. coverage 0인 `#lab=ai-regime`은 주 메뉴에서 숨기되 `데이터와 신뢰`에 blocked 상태를 보존해야 한다.
6. 390px에서 flow 계열 차트의 내부 가로 스크롤, `#ask`의 640px 고정 차트, `#track` 텍스트 오버플로, 질문 상세의 좌측 음수 위치가 관측됐다.

### 미충족 게이트

라이브 DOM 계측은 1280/390px에서 수행했지만 브라우저 CDP의 `Page.captureScreenshot` 타임아웃으로 전 라우트별 신규 1280/390 캡처 세트를 만들지 못했다. 패키지에는 기존 증거 이미지 4장을 포함했다. 이 사유로 U0를 완료로 표시하지 않았고 U1을 시작하지 않았다.

## 4. S0 계약 판정

### FINRA Margin Statistics

- 공식 페이지: <https://www.finra.org/rules-guidance/key-topics/margin-accounts/margin-statistics>
- 이용조건: <https://www.finra.org/terms-of-use>
- 허가 문의: <https://www.finra.org/contact-finra/permission-use-finra-copyrighted-material>
- 판정: 이용조건이 대량 복사·데이터베이스 생성·data mining 및 predictive analytics/AI 사용을 제한하므로 서면 허가 전 fetch 자체를 금지한다.
- 과거 행은 나중에 허가를 받더라도 `vintage=reconstructed`로만 취급한다.

### FRED NFCI

- 시리즈: <https://fred.stlouisfed.org/series/NFCI>
- FRED 이용조건: <https://fred.stlouisfed.org/legal/terms/>
- Chicago Fed 권리조건: <https://www.chicagofed.org/utilities/legal-notices>
- 판정: copyrighted/citation-required 시리즈이고 기반 권리는 Chicago Fed에 있으므로 자동 수집·재배포·모델 사용의 범위를 별도 확인하기 전 fetch를 금지한다.
- 기존 `fred_market_signals.yaml`의 `approved` 상태를 이 시리즈에 자동 상속하지 않는다.

### CFTC COT Bitcoin

- 데이터셋: `gpe5-46if` — Traders in Financial Futures, Futures Only.
- 계약 시장 코드: `133741` — CME Bitcoin.
- 공식 API: <https://publicreporting.cftc.gov/resource/gpe5-46if.json>
- 보고 기준: 화요일 포지션을 통상 금요일 15:30 ET 공개 시점으로 저장하며 화요일로 backdate하지 않는다.
- 2026-08-04 초기 probe: HTTP 200, 5행, 2,007 bytes, SHA-256 `620ab9c9506c9675e52d198db01c2c7b3a89734418b9d031ef089bac46aa34e5`.
- D0 관찰 기간: 2026-08-04부터 2026-08-17까지 14일, `window_end_exclusive=2026-08-18`.

## 5. 의도적으로 하지 않은 작업

- UI/CSS/dashboard JavaScript 변경 없음.
- collector 추가 없음.
- `data/source_registry.yaml` 등록 없음.
- 모델 확률·가중치·경로 변경 없음.
- 새 DB backfill 없음.
- U1/U2/S1/H1~H6 미착수.
- FINRA/NFCI transport probe 미실행: 법적 게이트가 fetch보다 먼저다.

## 6. 검증 결과

| 검증 | 결과 |
|---|---|
| `PYTHONPATH=src;dualdb python -m pytest -q` | 최종 커밋 전 재검증 `364 passed in 89.97s` |
| 신규 범위 테스트 | `5 passed` |
| `python -m ai_fc inventory --check` | `inventory current` |
| `python -m ai_fc audit-ledgers --check` | `violation=0`, `stalled=1`은 기존 의도된 경고 |
| `python -m ai_fc sync --check` | 종료 코드 0, 기존 Q1 quarantine 경고 2건 유지 |
| `node --check src/ai_fc/dashboard_parts/dashboard.js` | PASS |
| `_site/data.json` | 285,199 bytes, 320KB 예산 이내 |
| 원격 main | `d349c657cab64595fcb133385062962ebebb7ea3` 확인 |
| GitHub Actions verify | PASS — <https://github.com/Sung-JinPark/Jin-s-investing-prediction/actions/runs/30973763869> |
| GitHub Pages | PASS — <https://github.com/Sung-JinPark/Jin-s-investing-prediction/actions/runs/30973508704> |

첫 push `fec9af6`의 verify는 `docs/generated/inventory.generated.md` drift 한 건으로 실패했다. 원인은 계약 파일이 20개에서 23개로 증가했는데 결정론적 인벤토리를 재생성하지 않은 것이었다. 생성 명령으로 fingerprint와 계약 수만 갱신하고 `d349c65`를 추가 push했다. 테스트·UI·collector·registry에는 변경이 없다.

## 7. 독립 검토 명령

```powershell
git diff --stat cea5b9f..d349c65
git diff cea5b9f..d349c65 -- src/ai_fc data/source_registry.yaml
$env:PYTHONPATH='src;dualdb'
python -m pytest -q src/tests/test_u0_s0_scope.py
python -m pytest -q
python -m ai_fc audit-ledgers --check
python -m ai_fc sync --check
python -m ai_fc inventory --check
node --check src/ai_fc/dashboard_parts/dashboard.js
```

두 번째 명령에서 `src/ai_fc`와 `data/source_registry.yaml`의 diff가 비어 있어야 한다.

## 8. 검토자가 집중할 질문

1. U0 라우트 인벤토리가 실제 `COMMAND_ROUTES` 및 deep-link parser와 일치하는가?
2. 유지·통합·이동·숨김 결정이 §1.3 P1~P6과 모순되지 않는가?
3. 스크린샷 미충족을 `PARTIAL`로 판정하고 U1을 차단한 것이 충분한가?
4. FINRA와 NFCI의 법적 게이트가 과도하거나 부족하지 않은가?
5. CFTC가 disaggregated가 아닌 TFF Futures Only 데이터셋을 정확히 사용했는가?
6. `available_at`이 화요일 report date가 아니라 금요일 공개 시각으로 정의됐는가?
7. 계약 3개 모두 disabled·append-only·reconstructed backfill·reference_only를 강제하는가?
8. source registry와 collector를 아직 만들지 않은 순서 규율이 지켜졌는가?

## 9. 수용 기준

- U0 문서는 스크린샷 보충 전까지 `PARTIAL`로 유지한다.
- S0 계약은 초안으로 수용할 수 있으나 FINRA/NFCI는 권리 확인 전 활성화할 수 없다.
- CFTC도 14일 D0와 S1 승인 전 collector 또는 모델 입력으로 승격할 수 없다.
- 미충족 항목을 완료로 표시하거나 U1/S1을 선행 구현했다면 반려한다.
