# AI Investing Scenario V5.1 최종 검토서

작성 기준일: 2026-08-07 (Asia/Seoul)  
대상 저장소: `Sung-JinPark/Jin-s-investing-prediction`  
대상 PR: `#3 Harden Scenario V5.1 forecast semantics`  
최종 병합 커밋: `d363ece48421313b2eed1a81abeb82578dc31ed6`

## 1. 최종 판정

Scenario V5.1 구현, 검증, 커밋, 원격 푸시, PR 검증 및 `main` 병합은 완료됐다.

최종 판정은 다음과 같다.

- 연구 후보 구현: **완료**
- 통합 명세의 필수 의미 계약: **구현 완료**
- 공식 스냅샷·원장·아카이브 불변성: **유지**
- 후보 산출물 strict validation: **통과**
- 브라우저 표시 검증: **통과**
- PR GitHub Actions: **통과**
- 병합 후 `main` GitHub Actions: **통과**
- V5.1 공식 forecast/champion 승격: **하지 않음**
- V6 생성·승격: **차단 상태 유지**

따라서 V5.1은 "검토 가능한 연구 후보"로 병합됐지만, 공식 확률 원장이나 official snapshot을 대체하지 않는다.

## 2. 이번 변경이 해결한 핵심 문제

### 2.1 10월 2일을 exact-date forecast로 오인하는 문제

기존 그래프의 10월 2일 좌표는 샘플 경로가 특정 수준에 도달한 거래일 좌표였으며, 그 날짜 자체를 예측한 결과가 아니었다. V5.1에서는 이를 명시적으로 분리했다.

- `exact_date_forecast = false`
- 10월 2일은 "sampled trading-session coordinate"로 표시
- 하락 위험은 단일 날짜가 아니라 최초 터치 분포로 표시
- 경로 대표선과 날짜 예측을 의미적으로 분리

현재 -10% 최초 터치 분포는 다음과 같다.

| 항목 | 값 |
|---|---:|
| 고정 -10% 기준선 | 24,384.51 |
| 평가 구간 | 2026-08-07 ~ 2026-10-30 |
| 구간 내 한 번이라도 터치할 확률 | 19.0425% |
| 2026-10-02까지 누적 터치확률 | 14.2025% |
| 터치 조건부 p25 | 2026-09-01 |
| 터치 조건부 p50 | 2026-09-16 |
| 터치 조건부 p75 | 2026-10-05 |

위 날짜들은 "터치가 발생했다는 조건 아래의 분포 분위수"이며 확정 날짜가 아니다.

### 2.2 세 시나리오 선이 같은 모양을 반복하는 문제

2026 구간은 조건부 가중 p50을 굵은 실선으로, 실제로 시뮬레이션된 단일 member를 가는 점선으로 분리했다. 단일 member는 합성한 꺾은선이 아니라 실제 path ID다.

| 시나리오 | 실제 member path ID | 전체 경로 최대 낙폭 | terminal return |
|---|---:|---:|---:|
| S1 | 14,484 | -13.26% | 22.35% |
| S2 | 33,828 | -13.53% | 11.87% |
| S3 | 4,550 | -16.67% | 3.86% |

2026 대표 경로의 주간 수익률 상관은 S1/S2 `-0.0640`, S1/S3 `-0.0300`, S2/S3 `0.0075`로 계산됐고 same-shape gate를 통과했다.

반면 2027 continuation의 p50 level correlation은 `0.9951`, `0.9989`, `0.9929`로 매우 높았다. S1/S3 분포 거리도 기준에 못 미쳐 distinctness gate가 실패했다. 따라서 V5.1은 2027년에 서로 다른 세 선을 그리지 않는다.

- 2026: scenario-specific conditional distribution
- 2027: common-model continuation
- 2027에는 scenario-specific starting level만 유지
- distinctness 승인 전까지 세 개의 독립 continuation 표현 금지

### 2.3 미래 전망·시장 전망·리포트 인사이트의 무분별한 반영 문제

V5.1은 미래 전망과 시장·리포트 데이터를 무시하지 않는다. 대신 `available_at`, 시점 운송, 자기참조, 물리확률 변환 및 충격 매핑을 통과한 증거만 수치 계산에 허용한다.

현재 등록된 prospective view 9건과 보조 adapter 3종을 검토했지만 승인된 수치 view는 0건이다.

| 분류 | 건수 | 현재 처리 |
|---|---:|---|
| 동일 시나리오 계열에서 파생된 전망 | 2 | `REFERENCE_ONLY_ENDOGENOUS` |
| 이미 시작된 조정 구간 확률 | 1 | `BLOCKED_NEEDS_REFORECAST` |
| 이벤트 전망 | 3 | 상태 참고만 허용, 가격 충격 매핑 없음 |
| 시장·옵션 implied 전망 | 3 | 참고만 허용, physical probability 보정 없음 |
| liquidity/cross-asset/AI capital adapter | 3 | 승인된 PIT adapter가 없어 수치 미사용 |

이는 "인사이트가 없다"는 뜻이 아니라, 근거가 모델에 숫자로 들어갈 자격을 아직 갖추지 못했다는 뜻이다. 보고서에는 참고 근거와 차단 사유가 모두 보존된다.

## 3. 모델·데이터 계약 검토

### 3.1 후보 식별자와 상태

- Candidate ID: `scenario_v5_1_time_aligned_legacy_prior_v1`
- Schema version: 2
- Model family: `v5_1_time_aligned_evidence_conditioned_joint_path_ensemble`
- Prior engine: `legacy_gbm_reproduced_extended_v2`
- View engine: `entropy_pooling_dependency_capped_v2`
- Representative rule: `actual_weighted_medoid_v2`
- Promotion state: `research_candidate_degraded_no_approved_numerical_views`

### 3.2 Point-in-time 무결성

- Candidate as-of: `2026-08-06`
- Knowledge cutoff: `2026-08-07T04:06:20+00:00`
- strict `available_at` 검사: 통과
- future data 사용: 없음
- 승인된 numerical view: 0
- 모든 source SHA와 candidate identity를 build receipt에 고정

### 3.3 확률 및 posterior 진단

- canonical probability 단위는 `[0, 1]` fraction 유지
- path count: 40,000
- horizon: 252 거래 세션
- seed: 42
- numerical view가 0이므로 posterior iteration은 0
- effective sample size: 40,000
- maximum path weight: 0.000025
- top 1% weight share: 0.01
- posterior 및 dependency gate: 통과

현재 결과는 evidence-conditioned 구조를 갖췄지만 실제 수치 조정은 일어나지 않았다. 즉, legacy GBM prior를 정직하게 유지하면서 부적격 증거를 차단한 결과다.

### 3.4 Circularity와 dependency cap

다음 키를 이용해 중복·공통 원천을 식별한다.

- `origin_release_id`
- `dependency_cluster_id`
- `target_asset`
- `horizon_end`
- `view_kind`

Dependency cluster cap은 0.35다. 현재 수치 view가 없으므로 LOO matrix와 cluster influence는 `NOT_APPLICABLE_NO_APPROVED_NUMERICAL_VIEWS`로 기록됐다. 빈 진단을 임의 수치로 채우지 않았다.

## 4. 명세 Phase별 이행 검토

| Phase | 요구사항 | 구현·검토 결과 |
|---|---|---|
| 시작 전 안전검사 | official/ledger/archive 보호, baseline hash | 보호 파일 105개 manifest before/after 동일 |
| 기준선 재현 | Legacy V5 독립 재생, 기존 결과 비덮어쓰기 | 통과, 후보 전용 경로 사용 |
| 10/2 characterization | 날짜 의미 분리, first-touch distribution | 구현 완료, exact-date false |
| Phase A | loader, canonical hash, strict validator | 구현 및 strict verify 통과 |
| Phase B | time transport, drift, circularity, dependency cap | 구현 완료; 부적격 view 차단 |
| Phase C | evidence registry 및 adapter 상태 | 근거·상태·차단 사유 감사 가능 |
| Phase D | p50 primary, actual-member secondary, fan/risk label | 구현 및 브라우저 QA 통과 |
| Phase E | 2027 distinctness gate, V6 challenger 조건 | gate 실패 시 common continuation 적용 |
| Phase F | prior sensitivity | 10 seeds, 40k/100k/200k, drift retention 0/0.5/1 수행 |
| Phase G | 단위·회귀·브라우저 검증 | 전체 통과 |
| Phase H | 후보·보고서·증거 산출물 | 패키지에 포함 |

## 5. 표시 계약 검토

대시보드의 시각 의미는 다음과 같이 고정됐다.

| 표시 요소 | 계약 |
|---|---|
| 굵은 실선 | conditional weighted p50 |
| 가는 점선 | one actual simulated member |
| 점선 라벨 | `ONE SIMULATED MEMBER / EXACT DATES ARE NOT FORECAST` |
| 팬 차트 | posterior predictive unconditional bands |
| 숨긴 밴드 | 미니 패널 축 계산에서 제외 |
| 리스크 리본 | -10%선 누적 터치확률 저/중/고 |
| 2027 | distinctness 실패 시 common continuation |

브라우저 검증은 desktop, fan/timing/evidence, 2027 fallback, mobile banner, stale fallback 총 6개 화면에서 수행했다. Console error는 0건이었고 SVG에 `NaN` 또는 `Infinity`가 없음을 확인했다.

## 6. 불변성 및 보호 대상 검토

- Official snapshot SHA-256: `d8754e6a7d1eed4aa46c17625b7ba1e7b1554a4e9799404128d64e3277be75bc`
- Protected manifest before: `2e2f879733f4f6bc8d350af9a683917161234dd4ba2f59cbf4a4fef463d712d4`
- Protected manifest after: `2e2f879733f4f6bc8d350af9a683917161234dd4ba2f59cbf4a4fef463d712d4`
- 보호 파일 수: 105
- official snapshot 변경: 없음
- forecast/calibration/benchmark ledger 변경: 없음
- archive 변경: 없음
- 후보 파일은 `data/scenarios/candidates/`에만 추가

이 ZIP에는 official snapshot, forecast 원장, calibration 원장 및 archive 원문을 넣지 않았다. 보호 해시 보고서만 포함한다.

## 7. 테스트 및 전달 검증

### 7.1 로컬 검증

- `python -m pytest src/tests/test_scenario_v5_1.py -q`: 14 passed
- `python -m pytest -q`: 431 passed
- CI와 동일한 `python -m pytest src/tests -q`: 377 passed
- `node --check src/ai_fc/dashboard_parts/dashboard.js`: 통과
- `scenario-v5-1-verify`: 통과
- deterministic no-op rebuild: 통과
- `git diff --check`: 통과
- 브라우저 QA: 통과

Windows 작업트리에서 archive JSON의 `w/crlf`와 Git index의 `i/lf` 차이 때문에 로컬 ledger byte audit가 위반처럼 보이는 환경 차이가 있었다. 해당 archive는 수정하지 않았으며 Linux GitHub Actions에서는 registered ledger integrity check가 정상 통과했다.

### 7.2 CI와 병합

- 구현 커밋: `aeb283db44784a1fdf917480e51287bc3728386f`
- 생성물 갱신 커밋: `0fc2d870f096f501d2d514bbc7c265c03780fd10`
- PR: `https://github.com/Sung-JinPark/Jin-s-investing-prediction/pull/3`
- PR verify: 성공, run `31163148572`
- merge commit: `d363ece48421313b2eed1a81abeb82578dc31ed6`
- 병합 후 main verify: 성공, run `31163245147`

첫 PR verify에서는 새 파일이 `docs/generated/inventory.generated.md`에 반영되지 않아 generated inventory drift가 발생했다. 기존 생성 명령으로 inventory fingerprint와 `read_model_v2.schema.json`을 갱신했고, 별도 커밋 후 PR 및 main 검증이 모두 통과했다.

## 8. 잔여 모델 리스크와 승격 조건

### 8.1 현재 잔여 리스크

1. 승인된 numerical evidence가 0건이므로 경로 수치는 아직 legacy prior에 의존한다.
2. 시장·옵션 전망을 physical probability로 바꾸는 승인된 calibration이 없다.
3. 이벤트 surprise를 Nasdaq 가격 충격으로 바꾸는 PIT 검증 mapping이 없다.
4. 2027 분포 distinctness가 통과하지 않아 세 개의 독립 장기 시나리오를 주장할 수 없다.
5. 장기 PIT history 계약이 없어 EWMA/GARCH/RCFHS challenger를 정직하게 검증할 수 없다.
6. GitHub Actions에 Node.js 20 deprecation annotation이 있으나 이번 verify 결과에는 영향을 주지 않았다.
7. 브라우저 증거 6개는 기존 파일명이 `.png`이지만 실제 바이트 인코딩은 JPEG다. 화면 렌더링과 증거 해시에는 문제가 없으나 후속 정리에서 확장자와 인코딩을 일치시켜야 한다. 본 ZIP은 감사 추적성을 위해 병합된 원본 파일명과 바이트를 그대로 보존한다.

### 8.2 V6 차단 조건

다음 필드를 모든 modeling row에서 만족하는 승인된 장기 PIT dataset이 없다.

- `date`
- `value`
- `available_at`
- `source`
- `source_revision` 또는 `vintage`
- `response_sha` 또는 `content_sha`
- `ingested_at`

따라서 EWMA/GARCH filtered simulation, RCFHS stationary bootstrap, state transition 추정, 252/504/756/1260 lookback 비교, block-length 및 regime threshold 튜닝, rolling-origin 평가, coverage/calibration 및 human promotion은 차단 상태다. V6 후보 파일은 생성하지 않았다.

### 8.3 공식 승격 전 필수 후속 Gate

1. 독립적이고 PIT 적격인 numerical evidence 확보
2. 시장 implied probability의 physical calibration 승인
3. 이벤트 surprise-to-index-impact mapping 검증
4. shadow comparison과 tolerance 승인
5. 2027 distinctness 또는 common-continuation 정책의 인간 승인
6. official write 직전 question state, 만료, probability bounds 및 ledger gate 재검사
7. 모델 리스크 담당자의 명시적 promotion 승인

## 9. 패키지 구성

| 폴더 | 내용 |
|---|---|
| `00_REVIEW` | 본 최종 검토서 |
| `01_SPEC` | 통합 명세와 저장소 안전 규칙 |
| `02_IMPLEMENTATION` | 변경된 V5.1 구현 및 생성 계약 파일 |
| `03_TESTS` | V5/V5.1 테스트 소스 |
| `04_CANDIDATE` | 검증된 V5.1 후보 JSON |
| `05_AUDIT` | 데이터 품질, dependency, timing, distinctness, 보호 해시, 화면 증거, V6 blocker |
| `06_GIT` | 커밋·PR·CI 전달 기록 |
| `MANIFEST_SHA256.json` | ZIP 내부 파일별 크기와 SHA-256 |

## 10. 리뷰 권장 순서

1. 본 문서의 최종 판정과 잔여 리스크를 확인한다.
2. `01_SPEC`에서 절대 금지 및 최종 Gate를 확인한다.
3. `05_AUDIT`의 data quality와 evidence dependency CSV에서 각 view의 차단 사유를 확인한다.
4. timing JSON에서 any-touch, density, CDF 및 조건부 분위수를 확인한다.
5. distinctness JSON에서 2027 gate 실패 근거를 확인한다.
6. browser PNG에서 p50/actual-member, 날짜 비예측 라벨, stale fallback을 시각 검토한다.
7. `02_IMPLEMENTATION`과 `03_TESTS`에서 validator 및 회귀 테스트를 확인한다.
8. `MANIFEST_SHA256.json`으로 패키지 파일 무결성을 검증한다.

## 11. 최종 결론

V5.1은 날짜 정밀도 과장, 자기참조 증거, 부적절한 started-window 재사용, dependency 중복, 허위 2027 시나리오 분리를 차단하도록 개선됐다. 현재 수치 결과는 미래 인사이트를 임의 반영한 전망이 아니라, 근거가 Gate를 통과하지 못했음을 투명하게 드러낸 candidate다.

병합 자체는 완료됐고 모든 GitHub 검증이 통과했다. 다만 이 결과를 official forecast 또는 장기 구조모형으로 승격하는 것은 본 검토 범위 밖이며, 위에 명시한 데이터·모델·인간 승인 Gate가 충족될 때까지 금지된다.
