# Browser Evidence Format Note

`05_AUDIT/docs/audit/scenario_v5_1/browser/`의 6개 화면 증거는 저장소에서 `.png` 확장자로 관리되지만 실제 파일 signature는 JPEG(`FF D8 FF`)다.

본 검토 ZIP은 다음 원칙에 따라 파일을 변경하지 않았다.

- 병합된 감사 증거의 원래 파일명 유지
- 병합된 감사 증거의 바이트 및 SHA-256 유지
- JPEG 시작·종료 signature를 별도로 검증
- 형식 불일치를 최종 검토서의 잔여 artifact hygiene 항목에 공개

이 문제는 모델 결과, 후보 JSON, 표시 내용 또는 브라우저 렌더링의 의미를 바꾸지 않는다. 다만 향후 증거 생성기에서 실제 PNG로 저장하거나 `.jpg` 확장자를 사용하도록 정리하는 것이 권장된다.
